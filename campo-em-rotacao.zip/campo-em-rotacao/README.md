# Campo em Rotação

Simulador de rotação de culturas sob cenários de calor e chuva, com dados da NASA. Projeto independente para o desafio "Field Shift: Adapting Farms with NASA Data" do NASA International Space Apps Challenge 2026. Não é produto oficial da NASA e não tem afiliação com a agência nem com a Anthropic.

Servidor próprio em Node.js, sem nenhuma dependência para instalar (Node 20 ou mais novo).

## Rodar no seu computador

```bash
cp .env.example .env      # opcional
node server.js            # ou: npm start
# abra http://localhost:3000
```

No modo padrão (`MAIL_MODE=console`) nenhum e-mail sai de verdade. O link de confirmação aparece no terminal e em `data/outbox.log`.

Testes: `npm test` (modelo, e servidor com fornecedores simulados de NASA POWER, previsão do tempo e SMTP).

## O que o site faz

- **Simulador**: 11 locais de referência ou coordenada própria (busca a climatologia na NASA POWER), solo, irrigação, plantio direto, área, culturas permitidas, preço relativo, pesos de prioridade, cenários de clima, 2 a 4 anos de rotação. Gera 3 planos, calendário, teste de estresse (25 cenários) e tabela por cultura.
- **Histórico**: série mensal da NASA POWER desde 1991. Compara dois períodos à sua escolha (melhorou, piorou, estável), nota de cada ano, anos mais difíceis com o fator principal e uma faixa cultura por ano.
- **Projeção**: tendência linear de temperatura e chuva extrapolada até o ano escolhido, com casos "quente e seco" e "ameno e úmido", e o efeito sobre a sua rotação e o Plano A. Um botão aplica a tendência como cenário do simulador.
- **Tempo**: últimos 30 dias e próximos 16 dias contra a normal da gleba, alertas (seca, veranico, calor, geada) e situação de plantio de cada cultura no mês.
- **Conta**: cadastro com confirmação de e-mail, login, recuperação de senha, cenários salvos, exclusão de conta.

## Colocar no ar com endereço próprio

O site é um servidor Node comum. Precisa de um lugar onde ele rode o tempo todo e de um disco que não se apague (ele guarda usuários e cenários em `DATA_DIR/db.json`).

1. **Hospedagem.** Qualquer uma que rode Node ou Docker: Render, Railway, Fly.io, uma VPS. Há `Dockerfile` pronto (grava em `/data`; monte um volume ali).
2. **Domínio.** Registre um (registro.br para `.com.br`) e aponte o DNS para a hospedagem seguindo as instruções dela. HTTPS costuma ser automático. Atrás de proxy, defina `TRUST_PROXY=1`.
3. **Variáveis**: `BASE_URL=https://seudominio.com.br`, `COOKIE_SECURE=1`, `DATA_DIR` no disco persistente, `NODE_ENV=production`.
4. **E-mail real.** Troque `MAIL_MODE` por `resend`, `brevo` ou `smtp` e preencha as chaves (veja `.env.example`). Para os e-mails não caírem no spam, verifique o domínio de envio no provedor (SPF e DKIM). `MAIL_FROM` deve usar esse domínio. O SMTP embutido só fala TLS implícito (porta 465).

Sem nenhuma referência a terceiros no código além das fontes do Google Fonts (a CSP permite só isso) e das APIs de dados chamadas pelo servidor.

## Fontes de dados e termos

| Uso | Fonte | Observação |
|---|---|---|
| Climatologia e série histórica | NASA POWER (`power.larc.nasa.gov`) | dados abertos da NASA, comunidade AG |
| Previsão e últimos 30 dias | Open-Meteo | não é NASA. O plano gratuito é para uso não comercial. Uso comercial exige chave paga |

## O que foi testado e o que não foi

Testado aqui, automaticamente e no navegador: o modelo, as contas (cadastro, confirmação, login, redefinição de senha, isolamento entre usuários, senha com hash), o envio SMTP contra um servidor simulado, as rotas de histórico e tempo contra um fornecedor **simulado**, o tratamento de fornecedor fora do ar, e a interface em desktop, celular e tema escuro.

**Não testado**: o ambiente em que isto foi construído não tem acesso à internet. Por isso as chamadas reais à NASA POWER e à Open-Meteo nunca rodaram. O código segue o formato documentado das duas APIs, mas só foi verificado contra o simulador. O envio de e-mail por Resend, Brevo e SMTP com TLS também nunca saiu de fato. Faça uma conta de teste e uma consulta em cada aba logo após publicar.

Se a NASA não responder, as abas Histórico e Projeção mostram o erro e oferecem "Ver com série simulada", com aviso bem visível de que os números não são medições.

## Limites do modelo

Parâmetros de culturas simplificados, evapotranspiração por Hargreaves-Samani, projeção por tendência linear (não por modelo climático) e renda como índice relativo. É uma ferramenta de exploração, não substitui agrônomo nem o zoneamento agrícola de risco climático.
