/* Interface do simulador: estado, controles, abas, gráficos, conta e busca NASA POWER. */
(function () {
  'use strict';
  var M = window.Model, MONTHS = M.MONTHS, CROPS = M.CROPS;
  var $ = function (id) { return document.getElementById(id); };
  var f = function (x) { return Math.round(x * 100); };
  var fmt = function (x, d) { return x.toLocaleString('pt-BR', { maximumFractionDigits: d == null ? 1 : d }); };
  var cropName = function (id) { var c = M.byId(id); return c ? c.n.split(' (')[0] : id; };
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  var FALLBACK_CUR = ['soja', 'milho', 'soja', 'milho'];

  // ---------- estado ----------
  function num(v, a, b, d) { v = parseFloat(v); return isFinite(v) ? Math.max(a, Math.min(b, v)) : d; }
  function arr12(a, lo, hi) { if (!Array.isArray(a) || a.length !== 12) return null; var o = a.map(function (v) { return parseFloat(v); }); return o.every(function (v) { return isFinite(v) && v >= lo && v <= hi; }) ? o : null; }
  function sanitize(x) {
    var d = clone(M.DEFAULTS); d.regionId = 'sorriso'; d.climate = null;
    if (!x || typeof x !== 'object') return d;
    d.awc = num(x.awc, 40, 220, d.awc); d.dT = num(x.dT, 0, 5, d.dT); d.dP = num(x.dP, -40, 20, d.dP); d.irreg = num(x.irreg, 0, 50, d.irreg);
    d.wW = num(x.wW, 0, 10, d.wW); d.wS = num(x.wS, 0, 10, d.wS); d.wI = num(x.wI, 0, 10, d.wI); d.wR = num(x.wR, 0, 10, d.wR);
    d.years = Math.round(num(x.years, 2, 4, 3)); d.area = num(x.area, 1, 100000, d.area);
    d.irrig = ['none', 'partial', 'full'].indexOf(x.irrig) >= 0 ? x.irrig : 'none'; d.noTill = !!x.noTill;
    if (Array.isArray(x.allowed)) { var al = x.allowed.filter(function (id) { return !!M.byId(id); }); if (al.length >= 2) d.allowed = al; }
    if (x.price && typeof x.price === 'object') CROPS.forEach(function (c) { if (x.price[c.id] != null) d.price[c.id] = num(x.price[c.id], 0.5, 1.5, 1); });
    if (Array.isArray(x.cur)) d.cur = x.cur.filter(function (id) { return !!M.byId(id); }).slice(0, 4);
    if (M.REGIONS[x.regionId]) d.regionId = x.regionId;
    else if ((x.regionId === 'custom' || x.regionId === 'power') && x.climate) {
      var c = x.climate, t = arr12(c.t, -60, 60), p = arr12(c.p, 0, 3000);
      if (t && p) {
        d.regionId = x.regionId;
        d.climate = { n: String(c.n || 'Gleba').slice(0, 80), lat: num(c.lat, -90, 90, 0), lon: num(c.lon, -180, 180, 0), t: t, p: p, dtr: num(c.dtr, 2, 25, 10), source: String(c.source || '').slice(0, 120), tmax: arr12(c.tmax, -60, 70), tmin: arr12(c.tmin, -70, 60) };
        if (!d.climate.tmax || !d.climate.tmin) { delete d.climate.tmax; delete d.climate.tmin; }
      }
    }
    fixCur(d);
    return d;
  }
  function fixCur(d) {
    var n = Math.min(d.years, d.allowed.length); d.cur = d.cur.slice(0, d.years);
    for (var i = d.cur.length; i < d.years; i++) d.cur.push(FALLBACK_CUR[i % 4]);
    return n;
  }
  var st = sanitize(null);
  function persist() { try { localStorage.setItem('campo-state', JSON.stringify(st)); } catch (e) { /* sem armazenamento */ } }

  // ---------- clima ----------
  function getReg() {
    if (M.REGIONS[st.regionId]) { var r = clone(M.REGIONS[st.regionId]); r.source = 'Referência embutida (valores aproximados)'; return M.prep(r); }
    return M.prep(st.climate);
  }
  function opts() { return st; }

  // ---------- controles ----------
  function buildRegionSelect() {
    var s = $('region'), h = '';
    Object.keys(M.REGIONS).forEach(function (k) { h += '<option value="' + k + '">' + esc(M.REGIONS[k].n) + '</option>'; });
    if (st.regionId === 'power') h += '<option value="power">' + esc(st.climate.n) + '</option>';
    h += '<option value="custom">Gleba personalizada (digitar valores)</option>';
    s.innerHTML = h; s.value = st.regionId;
  }
  function buildCustomGrid() {
    var h = '<span class="h">mês</span><span class="h">°C</span><span class="h">mm</span>';
    for (var m = 0; m < 12; m++) h += '<span class="mono">' + MONTHS[m] + '</span><input type="number" id="ct' + m + '" step="0.5" aria-label="Temperatura média em ' + MONTHS[m] + '"><input type="number" id="cp' + m + '" min="0" step="5" aria-label="Chuva em ' + MONTHS[m] + '">';
    $('customGrid').innerHTML = h;
  }
  function fillCustom() { if (!st.climate) return; for (var m = 0; m < 12; m++) { $('ct' + m).value = st.climate.t[m]; $('cp' + m).value = st.climate.p[m]; } $('cdtr').value = st.climate.dtr; }
  function buildScenarios() {
    $('scBtns').innerHTML = M.SCENARIOS.map(function (s) { return '<button type="button" class="chipb" data-id="' + s.id + '">' + s.n + '</button>'; }).join('');
  }
  function buildCrops() {
    $('cropList').innerHTML = CROPS.map(function (c) {
      var p = st.price[c.id] == null ? 1 : st.price[c.id];
      return '<div class="crow"><input type="checkbox" data-crop="' + c.id + '" id="ck-' + c.id + '" aria-label="Aceito plantar ' + esc(cropName(c.id)) + '"><label for="ck-' + c.id + '">' + esc(cropName(c.id)) + '</label>' +
        '<input type="range" min="0.5" max="1.5" step="0.1" data-price="' + c.id + '" aria-label="Preço relativo de ' + esc(cropName(c.id)) + '" value="' + p + '"><span class="mono" id="pv-' + c.id + '">' + fmt(p) + '×</span></div>';
    }).join('');
  }
  function buildCur() {
    var h = '';
    for (var i = 0; i < st.years; i++) {
      h += '<div class="fld"><label for="cur' + i + '">Ano ' + (i + 1) + '</label><select id="cur' + i + '" data-cur="' + i + '">' +
        CROPS.map(function (c) { return '<option value="' + c.id + '">' + esc(cropName(c.id)) + '</option>'; }).join('') + '</select></div>';
    }
    $('curBox').innerHTML = h;
    for (var j = 0; j < st.years; j++) $('cur' + j).value = st.cur[j];
  }
  function syncControls() {
    buildRegionSelect(); buildCur();
    var reg = getReg();
    $('lat').value = reg.lat == null ? '' : reg.lat; $('lon').value = reg.lon == null ? '' : reg.lon;
    $('customBox').hidden = st.regionId !== 'custom'; if (st.regionId === 'custom') fillCustom();
    $('awc').value = st.awc; $('noTill').checked = st.noTill; $('area').value = st.area;
    ['dT', 'dP', 'irreg', 'wW', 'wS', 'wI', 'wR'].forEach(function (k) { $(k).value = st[k]; });
    CROPS.forEach(function (c) {
      $('ck-' + c.id).checked = st.allowed.indexOf(c.id) >= 0;
      var p = st.price[c.id] == null ? 1 : st.price[c.id]; document.querySelector('[data-price="' + c.id + '"]').value = p; $('pv-' + c.id).textContent = fmt(p) + '×';
    });
  }
  function paintToggles() {
    $('awco').textContent = st.awc + ' mm';
    $('dTo').textContent = '+' + fmt(st.dT) + ' °C'; $('dPo').textContent = (st.dP > 0 ? '+' : '') + st.dP + '%'; $('irrego').textContent = st.irreg + '%';
    ['wW', 'wS', 'wI', 'wR'].forEach(function (k) { $(k + 'o').textContent = st[k] + ' / 10'; });
    Array.prototype.forEach.call($('soilBtns').children, function (b) { b.setAttribute('aria-pressed', String(+b.dataset.v === st.awc)); });
    Array.prototype.forEach.call($('irrig').children, function (b) { b.setAttribute('aria-pressed', String(b.dataset.v === st.irrig)); });
    Array.prototype.forEach.call($('years').children, function (b) { b.setAttribute('aria-pressed', String(+b.dataset.v === st.years)); });
    Array.prototype.forEach.call($('scBtns').children, function (b) {
      var s = M.SCENARIOS.filter(function (x) { return x.id === b.dataset.id; })[0];
      b.setAttribute('aria-pressed', String(s.dT === st.dT && s.dP === st.dP && s.irreg === st.irreg));
    });
  }
  var queued = false;
  function change(rebuildCur) { if (rebuildCur) buildCur(); persist(); if (!queued) { queued = true; requestAnimationFrame(function () { queued = false; render(); }); } }

  function bind() {
    $('region').onchange = function () {
      var v = this.value;
      if (v === 'custom') {
        if (!st.climate || st.regionId !== 'custom') {
          var r = getReg(); st.climate = { n: 'Gleba personalizada', lat: r.lat == null ? 0 : r.lat, lon: r.lon == null ? 0 : r.lon, t: r.t.map(function (x) { return +x.toFixed(1); }), p: r.p.map(Math.round), dtr: +(r.tmax[0] - r.tmin[0]).toFixed(1) || 10, source: 'Valores informados por você' };
        }
      }
      st.regionId = v; syncControls(); change();
    };
    $('lat').oninput = function () { if (st.regionId === 'custom') { st.climate.lat = num(this.value, -90, 90, 0); change(); } };
    $('lon').oninput = function () { if (st.regionId === 'custom') { st.climate.lon = num(this.value, -180, 180, 0); change(); } };
    $('fetchBtn').onclick = function () {
      var lat = parseFloat($('lat').value), lon = parseFloat($('lon').value);
      if (!(lat >= -90 && lat <= 90) || !(lon >= -180 && lon <= 180)) { $('srcText').textContent = 'Informe latitude e longitude válidas.'; return; }
      var b = this; b.disabled = true; b.textContent = 'Buscando na NASA…';
      Api('GET', '/api/power?lat=' + lat + '&lon=' + lon).then(function (j) {
        st.regionId = 'power';
        st.climate = { n: 'NASA POWER · ' + lat.toFixed(2) + ', ' + lon.toFixed(2), lat: lat, lon: lon, t: j.t, p: j.p, dtr: 10, source: 'NASA POWER · climatologia mensal · consultado em ' + new Date(j.fetchedAt).toLocaleDateString('pt-BR') };
        if (j.tmax && j.tmin) { st.climate.tmax = j.tmax; st.climate.tmin = j.tmin; }
        st = sanitize(st); syncControls(); change();
      }).catch(function (e) { $('srcText').textContent = 'Não foi possível buscar: ' + e.message; })
        .then(function () { b.disabled = false; b.textContent = 'Buscar clima na NASA POWER'; });
    };
    $('customGrid').oninput = function () {
      if (st.regionId !== 'custom') return;
      for (var m = 0; m < 12; m++) { st.climate.t[m] = num($('ct' + m).value, -60, 60, 0); st.climate.p[m] = num($('cp' + m).value, 0, 3000, 0); }
      change();
    };
    $('cdtr').oninput = function () { if (st.regionId === 'custom') { st.climate.dtr = num(this.value, 2, 25, 10); change(); } };
    $('soilBtns').onclick = function (e) { var v = e.target.dataset && e.target.dataset.v; if (v) { st.awc = +v; $('awc').value = v; change(); } };
    $('irrig').onclick = function (e) { var v = e.target.dataset && e.target.dataset.v; if (v) { st.irrig = v; change(); } };
    $('years').onclick = function (e) { var v = e.target.dataset && e.target.dataset.v; if (v) { st.years = +v; fixCur(st); change(true); } };
    $('scBtns').onclick = function (e) {
      var id = e.target.dataset && e.target.dataset.id; if (!id) return;
      var s = M.SCENARIOS.filter(function (x) { return x.id === id; })[0]; st.dT = s.dT; st.dP = s.dP; st.irreg = s.irreg;
      ['dT', 'dP', 'irreg'].forEach(function (k) { $(k).value = st[k]; }); change();
    };
    ['awc', 'dT', 'dP', 'irreg', 'wW', 'wS', 'wI', 'wR', 'area'].forEach(function (k) { $(k).oninput = function () { st[k] = +this.value; if (k === 'area') st.area = num(this.value, 1, 100000, 1); change(); }; });
    $('noTill').onchange = function () { st.noTill = this.checked; change(); };
    $('cropList').oninput = function (e) {
      var t = e.target, id = t.dataset.crop, pid = t.dataset.price;
      if (id) {
        var i = st.allowed.indexOf(id);
        if (t.checked && i < 0) st.allowed.push(id);
        else if (!t.checked && i >= 0) { if (st.allowed.length <= 2) { t.checked = true; flash('Deixe pelo menos 2 culturas marcadas.'); return; } st.allowed.splice(i, 1); }
        change();
      } else if (pid) { st.price[pid] = +t.value; $('pv-' + pid).textContent = fmt(+t.value) + '×'; change(); }
    };
    $('curBox').onchange = function (e) { var i = e.target.dataset.cur; if (i != null) { st.cur[+i] = e.target.value; change(); } };
    $('resetBtn').onclick = function () { st = sanitize(null); syncControls(); change(true); };
    document.querySelector('.controls').addEventListener('submit', function (e) { e.preventDefault(); });
    var tabs = document.querySelectorAll('.tabs button');
    Array.prototype.forEach.call(tabs, function (b) {
      b.onclick = function () {
        Array.prototype.forEach.call(tabs, function (x) { x.setAttribute('aria-selected', String(x === b)); });
        document.querySelectorAll('.tp').forEach(function (p) { p.hidden = p.id !== 'tp-' + b.dataset.tab; });
      };
    });
    $('planSel').onclick = function (e) { var v = e.target.dataset && e.target.dataset.v; if (v != null) { planIdx = +v; renderCal(); } };
    $('copyBtn').onclick = function () { copyText(lastSummary, 'Resumo copiado.', true); };
    $('linkBtn').onclick = function () { copyText(location.origin + '/?s=' + encodeState() + '#simulador', 'Link copiado.', false); };
    $('saveBtn').onclick = function () {
      var u = window.currentUser();
      if (!u) { location.href = '/entrar.html?next=' + encodeURIComponent('/?s=' + encodeState() + '#simulador'); return; }
      if (!u.verified) return flash('Confirme seu e-mail para salvar. Use "Reenviar e-mail" no aviso do topo.');
      $('saveRow').hidden = false; $('saveName').value = $('saveName').value || (getReg().n.split(',')[0] + ' · +' + fmt(st.dT) + ' °C'); $('saveName').focus(); $('saveName').select();
    };
    $('saveOk').onclick = function () {
      var b = this; b.disabled = true;
      Api('POST', '/api/plans', { name: $('saveName').value, state: st, summary: lastBrief })
        .then(function () { $('saveRow').hidden = true; flash('Cenário salvo em "Minha conta".'); })
        .catch(function (e) { flash(e.message); }).then(function () { b.disabled = false; });
    };
  }
  var flashT;
  function flash(t) { var el = $('actMsg'); el.textContent = t; clearTimeout(flashT); flashT = setTimeout(function () { el.textContent = ''; }, 5000); }
  function copyText(text, okMsg, showBox) {
    var box = $('sumBox'); box.value = text;
    function fb() { box.hidden = false; box.focus(); box.select(); flash('Selecione e copie o texto abaixo.'); }
    try { navigator.clipboard.writeText(text).then(function () { flash(okMsg); if (showBox) box.hidden = true; }, fb); } catch (e) { fb(); }
  }
  function encodeState() { return btoa(unescape(encodeURIComponent(JSON.stringify(st)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function decodeState(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return JSON.parse(decodeURIComponent(escape(atob(s)))); }

  // ---------- gráficos ----------
  var MONO = 'IBM Plex Mono,monospace';
  function txt(x, y, s, anchor) { return '<text x="' + x + '" y="' + y + '" text-anchor="' + (anchor || 'middle') + '" font-size="10" fill="var(--muted)" font-family="' + MONO + '">' + s + '</text>'; }
  function drawClimate(rows) {
    var W = 640, H = 250, L = 46, R = 46, T = 16, B = 28, pw = W - L - R, ph = H - T - B, bw = pw / 12;
    var pmax = Math.ceil(Math.max.apply(null, rows.map(function (r) { return Math.max(r.p0, r.p1); })) * 1.1 / 50) * 50 || 50;
    var tmin = Math.floor((Math.min.apply(null, rows.map(function (r) { return r.t0; })) - 2) / 10) * 10, tmax = Math.ceil((Math.max.apply(null, rows.map(function (r) { return r.t1; })) + 2) / 10) * 10;
    var y = function (v) { return T + ph - v / pmax * ph; }, yt = function (v) { return T + ph - (v - tmin) / (tmax - tmin) * ph; };
    var s = '';
    for (var i = 0; i <= 4; i++) {
      var gy = T + ph * (1 - i / 4);
      s += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + gy + '" y2="' + gy + '" stroke="var(--line)"/>' + txt(L - 6, gy + 4, Math.round(pmax * i / 4), 'end') + txt(W - R + 6, gy + 4, Math.round(tmin + (tmax - tmin) * i / 4) + '°', 'start');
    }
    s += txt(L, 10, 'mm/mês', 'start');
    rows.forEach(function (r, m) {
      var x = L + m * bw;
      s += '<rect x="' + (x + bw * 0.12) + '" y="' + y(r.p0) + '" width="' + (bw * 0.76) + '" height="' + (T + ph - y(r.p0)) + '" fill="var(--sky)" opacity="0.28"/>';
      s += '<rect x="' + (x + bw * 0.3) + '" y="' + y(r.p1) + '" width="' + (bw * 0.4) + '" height="' + (T + ph - y(r.p1)) + '" fill="var(--sky)"/>' + txt(x + bw / 2, H - 10, MONTHS[m]);
    });
    var line = function (key, col) { return '<polyline fill="none" stroke="' + col + '" stroke-width="2.2" stroke-linejoin="round" points="' + rows.map(function (r, m) { return (L + m * bw + bw / 2) + ',' + yt(r[key]); }).join(' ') + '"/>'; };
    s += line('t0', 'var(--muted)') + line('t1', 'var(--soil)') + '<circle cx="' + (L + 11 * bw + bw / 2) + '" cy="' + yt(rows[11].t1) + '" r="3.5" fill="var(--soil)"/>';
    $('chart1').innerHTML = s;
  }
  function drawBalance(rows) {
    var W = 640, H = 230, L = 46, R = 16, T = 14, B = 28, pw = W - L - R, ph = H - T - B, bw = pw / 12;
    var mx = Math.max.apply(null, rows.map(function (r) { return Math.max(Math.abs(r.bal1), Math.abs(r.bal0)); }));
    var lim = Math.max(50, Math.ceil(mx * 1.1 / 50) * 50), y = function (v) { return T + ph / 2 - v / lim * ph / 2; };
    var s = '';
    [-1, -0.5, 0, 0.5, 1].forEach(function (k) { var gy = y(k * lim); s += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + gy + '" y2="' + gy + '" stroke="' + (k === 0 ? 'var(--fg)' : 'var(--line)') + '"/>' + txt(L - 6, gy + 4, Math.round(k * lim), 'end'); });
    rows.forEach(function (r, m) {
      var x = L + m * bw, y0 = y(0), y1 = y(r.bal1), top = Math.min(y0, y1), h = Math.abs(y1 - y0);
      s += '<rect x="' + (x + bw * 0.18) + '" y="' + top + '" width="' + (bw * 0.64) + '" height="' + Math.max(h, 1) + '" fill="' + (r.bal1 >= 0 ? 'var(--field)' : 'var(--warn)') + '"/>';
      s += '<line x1="' + (x + bw * 0.1) + '" x2="' + (x + bw * 0.9) + '" y1="' + y(r.bal0) + '" y2="' + y(r.bal0) + '" stroke="var(--fg)" stroke-width="2.5"/>' + txt(x + bw / 2, H - 10, MONTHS[m]);
    });
    $('chart2').innerHTML = s;
  }

  // ---------- renderização ----------
  var lastSummary = '', lastBrief = '', planIdx = 0, cache = {};
  var hooks = [];
  function render() { renderCore(); hooks.forEach(function (fn) { try { fn(); } catch (e) { console.error(e); } }); }
  function renderCore() {
    paintToggles();
    var reg = getReg(), o = opts();
    $('lat').placeholder = reg.lat == null ? '' : reg.lat;
    var live = st.regionId === 'power';
    $('srcBadge').className = 'src' + (live ? ' live' : ''); $('srcText').textContent = (live ? 'Dados da NASA. ' : '') + (reg.source || 'Referência embutida') + '. Para a sua gleba, busque pela coordenada.';
    var S = M.suitAll(reg, o), plans = M.plansFor(S, o, 3), cur = M.scoreRot(st.cur, S, o), rows = M.monthlyClimate(reg, o);
    var A = plans[0];
    cache = { reg: reg, S: S, plans: plans, cur: cur, rows: rows };
    $('plansTitle').textContent = 'Planos de rotação para ' + (A ? A.ids.length : st.years) + ' anos';
    renderClima(reg, rows);
    if (!A) { $('plans').innerHTML = '<p class="note">Marque pelo menos 2 culturas para ver planos.</p>'; $('kpis').innerHTML = ''; return; }
    var stress = M.stress([st.cur, A.ids], reg, o);
    renderKpis(A, cur, stress);
    $('plans').innerHTML = plans.map(function (p, i) { return planCard(p, i); }).join('');
    var d = f(A.total) - f(cur.total);
    $('cmpText').innerHTML = '<p><b>' + st.cur.map(cropName).join(' → ') + '</b> tem nota <b class="mono">' + f(cur.total) + '</b> neste cenário. O Plano A tem <b class="mono">' + f(A.total) + '</b>.</p>' +
      '<p class="note" style="margin-top:6px">Pior ano da sua rotação: ' + f(cur.res) + ' de 100 em adaptação. Balanço de nitrogênio: ' + (cur.nb >= 0 ? '+' : '') + Math.round(cur.nb) + ' kg/ha/ano.</p>';
    var de = $('cmpDelta'); de.textContent = (d > 0 ? '+' : '') + d + ' pts'; de.style.color = d > 0 ? 'var(--field)' : 'var(--fg)';
    if (planIdx >= plans.length) planIdx = 0;
    renderCal(); renderStress(stress, A, reg); renderCrops(S);
    var irr = { none: 'sem irrigação', partial: 'irrigação suplementar', full: 'irrigação plena' }[st.irrig];
    lastBrief = reg.n.split(',')[0] + ' · Plano A ' + f(A.total) + '/100 · ' + A.ids.map(cropName).join(' → ');
    lastSummary = 'Campo em Rotação · ' + reg.n + '\nCenário: +' + fmt(st.dT) + ' °C, chuva ' + (st.dP > 0 ? '+' : '') + st.dP + '%, irregularidade ' + st.irreg + '%, solo com ' + st.awc + ' mm de água disponível, ' + irr + (st.noTill ? ', plantio direto' : '') +
      '\n\nPlano A (nota ' + f(A.total) + '/100; sua rotação atual ' + f(cur.total) + '/100):\n' +
      A.cs.map(function (x, k) { return 'Ano ' + (k + 1) + ': ' + x.c.n + ', plantio em ' + MONTHS[x.start]; }).join('\n') +
      '\nNitrogênio no solo: ' + (A.nb >= 0 ? '+' : '') + Math.round(A.nb) + ' kg/ha/ano\n\nSimulação exploratória. Validar com agrônomo local.';
  }
  function renderKpis(A, cur, stress) {
    var d = f(A.total) - f(cur.total), vol = A.needm * 10 * st.area / 1000, nT = A.nb * st.area / 1000;
    $('kpis').innerHTML =
      '<div class="kpi good"><small>Nota do Plano A</small><strong>' + f(A.total) + '</strong><em>de 100</em></div>' +
      '<div class="kpi ' + (d > 0 ? 'good' : '') + '"><small>Ganho sobre a atual</small><strong>' + (d > 0 ? '+' : '') + d + ' pts</strong><em>sua rotação: ' + f(cur.total) + '</em></div>' +
      '<div class="kpi"><small>Pior cenário da grade</small><strong>' + f(stress.min[1]) + '</strong><em>sua rotação: ' + f(stress.min[0]) + '</em></div>' +
      '<div class="kpi"><small>Demanda de água</small><strong>' + Math.round(A.needm) + ' mm</strong><em>por ciclo, ≈ ' + fmt(vol, vol < 10 ? 1 : 0) + ' mil m³ em ' + fmt(st.area, 0) + ' ha</em></div>' +
      '<div class="kpi ' + (A.nb >= 0 ? 'good' : 'bad') + '"><small>Nitrogênio no solo</small><strong>' + (A.nb >= 0 ? '+' : '') + Math.round(A.nb) + ' kg/ha</strong><em>por ano, ≈ ' + (nT >= 0 ? '+' : '') + fmt(nT) + ' t na gleba</em></div>';
  }
  function planCard(p, i) {
    var seq = p.cs.map(function (x, k) {
      return '<div class="step"><span class="yr">Ano ' + (k + 1) + '</span><span>' + esc(x.c.n) + '</span><span class="sw">plantio em ' + MONTHS[x.start] + ' · chuva útil ' + Math.round(x.rainEff) + ' de ' + Math.round(x.need) + ' mm</span></div>';
    }).join('');
    var bars = [['Adaptação', p.adapt], ['Água', p.water], ['Solo', p.soil], ['Renda', p.inc], ['Resiliência', p.res]].map(function (b) {
      return '<div class="bar"><span>' + b[0] + '</span><div><i style="width:' + f(b[1]) + '%"></i></div><b>' + f(b[1]) + '</b></div>';
    }).join('');
    var defi = M.sum(p.cs.map(function (x) { return x.deficit; })) / p.cs.length;
    return '<article class="plan' + (i === 0 ? ' top' : '') + '"><header><div><div class="eyebrow">' + (i === 0 ? 'Recomendado' : 'Alternativa ' + i) + '</div><h3 style="margin-top:4px">Plano ' + 'ABC'[i] + '</h3></div><div class="score">' + f(p.total) + '<small> /100</small></div></header>' +
      '<div class="seq">' + seq + '</div><div class="bars">' + bars + '</div><div class="chips" style="display:flex;gap:6px;flex-wrap:wrap">' +
      '<span class="chip ' + (p.nb >= 0 ? 'pos' : 'neg') + '">N no solo ' + (p.nb >= 0 ? '+' : '') + Math.round(p.nb) + ' kg/ha/ano</span>' +
      '<span class="chip ' + (defi > 20 ? 'neg' : '') + '">déficit médio ' + Math.round(defi) + ' mm</span></div></article>';
  }
  function renderClima(reg, rows) {
    $('regTitle').textContent = reg.n; $('regCoord').textContent = reg.lat == null ? '' : Math.abs(reg.lat).toFixed(1) + (reg.lat < 0 ? '°S ' : '°N ') + Math.abs(reg.lon || 0).toFixed(1) + ((reg.lon || 0) < 0 ? '°O' : '°L');
    var P0 = M.sum(rows.map(function (r) { return r.p0; })), P1 = M.sum(rows.map(function (r) { return r.p1; }));
    var E0 = M.sum(rows.map(function (r) { return r.eto0; })), E1 = M.sum(rows.map(function (r) { return r.eto1; }));
    var T0 = M.sum(reg.t) / 12, dry = function (k) { return rows.filter(function (r) { return r[k] < 50; }).length; };
    var neg = rows.filter(function (r) { return r.bal1 < 0; }).length;
    $('cKpis').innerHTML =
      '<div class="kpi"><small>Chuva anual</small><strong>' + Math.round(P1) + ' mm</strong><em>hoje ' + Math.round(P0) + ' mm</em></div>' +
      '<div class="kpi"><small>Temperatura média</small><strong>' + fmt(T0 + st.dT) + ' °C</strong><em>hoje ' + fmt(T0) + ' °C</em></div>' +
      '<div class="kpi"><small>ETo anual</small><strong>' + Math.round(E1) + ' mm</strong><em>hoje ' + Math.round(E0) + ' mm</em></div>' +
      '<div class="kpi ' + (neg > 6 ? 'bad' : '') + '"><small>Meses com falta de água</small><strong>' + neg + '</strong><em>chuva útil &lt; ETo</em></div>' +
      '<div class="kpi"><small>Meses secos (&lt; 50 mm)</small><strong>' + dry('p1') + '</strong><em>hoje ' + dry('p0') + '</em></div>';
    drawClimate(rows); drawBalance(rows);
    var h = '<thead><tr><th>Mês</th><th class="n">T méd °C</th><th class="n">T máx °C</th><th class="n">T mín °C</th><th class="n">Chuva hoje</th><th class="n">Chuva cenário</th><th class="n">ETo</th><th class="n">Saldo</th></tr></thead><tbody>';
    rows.forEach(function (r) {
      h += '<tr><td>' + MONTHS[r.m] + '</td><td class="n">' + fmt(r.t1) + '</td><td class="n">' + fmt(r.tmax1) + '</td><td class="n">' + fmt(r.tmin1) + '</td><td class="n">' + Math.round(r.p0) + '</td><td class="n">' + Math.round(r.p1) + '</td><td class="n">' + Math.round(r.eto1) + '</td><td class="n" style="color:' + (r.bal1 < 0 ? 'var(--warn)' : 'var(--field)') + '">' + (r.bal1 > 0 ? '+' : '') + Math.round(r.bal1) + '</td></tr>';
    });
    $('climTbl').innerHTML = h + '</tbody>';
  }
  var famCls = function (x) { return x.c.fam === 'leg' ? 'leg' : (x.c.fam === 'gra' ? 'gra' : 'oth'); };
  function renderCal() {
    var plans = cache.plans; if (!plans || !plans[planIdx]) return;
    Array.prototype.forEach.call($('planSel').children, function (b, i) { b.hidden = !plans[i]; b.setAttribute('aria-pressed', String(i === planIdx)); });
    var P = plans[planIdx], h = '<thead><tr><th></th>' + MONTHS.map(function (m) { return '<th>' + m + '</th>'; }).join('') + '</tr></thead><tbody>';
    P.cs.forEach(function (x, k) {
      h += '<tr><td>Ano ' + (k + 1) + ' · ' + esc(cropName(x.c.id)) + '</td>';
      for (var m = 0; m < 12; m++) h += '<td class="cal' + (((m - x.start + 12) % 12) < x.c.L ? ' ' + famCls(x) : '') + '"></td>';
      h += '</tr>';
    });
    $('cal').innerHTML = h + '</tbody>';
    var dry = cache.rows.filter(function (r) { return r.p1 < 50; }).map(function (r) { return MONTHS[r.m]; });
    $('calNote').textContent = (dry.length ? 'Meses com menos de 50 mm no cenário: ' + dry.join(', ') + '. ' : 'Nenhum mês abaixo de 50 mm neste cenário. ') + 'Cada linha mostra o ciclo da cultura no melhor mês de plantio.';
    var H = '<thead><tr><th></th>' + MONTHS.map(function (m) { return '<th>' + m + '</th>'; }).join('') + '</tr></thead><tbody>';
    st.allowed.forEach(function (id) {
      var s = cache.S[id]; if (!s) return;
      H += '<tr><td>' + esc(cropName(id)) + '</td>' + s.by.map(function (v, m) { return '<td class="c' + (m === s.start ? ' best' : '') + '" style="--v:' + v.toFixed(2) + '" title="' + esc(cropName(id)) + ', plantio em ' + MONTHS[m] + ': ' + f(v) + '"></td>'; }).join('') + '</tr>';
    });
    $('heat').innerHTML = H + '</tbody>';
  }
  function renderStress(r, A, reg) {
    function tbl(q) {
      var t = '<table class="heat stress"><thead><tr><th>chuva \\ aquec.</th>' + r.dTs.map(function (d) { return '<th>+' + d + '°C</th>'; }).join('') + '</tr></thead><tbody>';
      r.dPs.forEach(function (dp, ri) {
        t += '<tr><td>' + (dp > 0 ? '+' : '') + dp + '%</td>' + r.M[q][ri].map(function (v, ci) {
          return '<td class="c' + (r.dTs[ci] === st.dT && dp === st.dP ? ' best' : '') + '" style="--v:' + (v * 0.6).toFixed(2) + '">' + f(v) + '</td>';
        }).join('') + '</tr>';
      });
      return t + '</tbody></table>';
    }
    $('stress').innerHTML = '<div><h4>Sua rotação: ' + esc(st.cur.map(cropName).join(' → ')) + '</h4><div class="scroll">' + tbl(0) + '</div></div><div><h4>Plano A: ' + esc(A.ids.map(cropName).join(' → ')) + '</h4><div class="scroll">' + tbl(1) + '</div></div>';
    $('stressNote').textContent = 'Pior cenário da grade: sua rotação ' + f(r.min[0]) + ', Plano A ' + f(r.min[1]) + '. O contorno marca o cenário escolhido, quando ele está na grade. O Plano A foi escolhido no cenário selecionado e reavaliado nos demais. A irrigação, o solo e os pesos valem para toda a grade.';
  }
  function renderCrops(S) {
    var list = CROPS.map(function (c) { return S[c.id]; }).sort(function (a, b) { return b.best - a.best; });
    var h = '<thead><tr><th>Cultura</th><th>Família</th><th>Plantio</th><th>Aptidão</th><th class="n">Demanda mm</th><th class="n">Chuva útil mm</th><th class="n">Déficit mm</th><th class="n">Meses de calor</th><th class="n">Meses de geada</th><th class="n">N kg/ha</th><th>Observação</th></tr></thead><tbody>';
    list.forEach(function (s) {
      var c = s.c, out = st.allowed.indexOf(c.id) < 0;
      h += '<tr' + (out ? ' style="opacity:.55"' : '') + '><td><b>' + esc(cropName(c.id)) + '</b>' + (out ? '<br><span class="note">fora da sua lista</span>' : '') + '</td><td>' + M.FAMILIES[c.fam] + '</td><td>' + MONTHS[s.start] + '</td>' +
        '<td><span class="mini"><i style="width:' + f(s.best) + '%"></i></span> <span class="mono">' + f(s.best) + '</span></td><td class="n">' + Math.round(s.need) + '</td><td class="n">' + Math.round(s.rainEff) + '</td><td class="n" style="color:' + (s.deficit > 20 ? 'var(--warn)' : 'inherit') + '">' + Math.round(s.deficit) + '</td>' +
        '<td class="n">' + s.heatN + '</td><td class="n">' + s.frostN + '</td><td class="n">' + (c.nb > 0 ? '+' : '') + c.nb + '</td><td style="min-width:240px">' + esc(c.note) + '</td></tr>';
    });
    $('cultTbl').innerHTML = h + '</tbody>';
  }

  // ---------- abertura e missões ----------
  function hero() {
    var h = '';
    for (var i = 0; i < 96; i++) {
      var col = i % 12, row = Math.floor(i / 12), v = 0.25 + 0.7 * Math.abs(Math.sin(col * 0.8 + row * 1.6) * Math.cos(row * 0.8 - col * 0.33));
      if (col > 8 && row > 3) v = 0.12 + v * 0.3;
      h += '<span style="--i:' + i + ';background:color-mix(in srgb,var(--field) ' + Math.round(v * 100) + '%,var(--surface2))"></span>';
    }
    $('px').innerHTML = h;
  }
  function missions() {
    $('missions').innerHTML = (window.MISSIONS || []).map(function (m) {
      return '<article class="mcard"><span class="k">' + esc(m.k) + '</span><h3>' + esc(m.n) + '</h3><p>' + esc(m.d) + '</p><p class="use"><b>No site:</b> ' + esc(m.u) + '</p>' +
        '<div class="st"><span class="pill' + (m.on ? ' on' : '') + '">' + (m.on ? 'Ativo' : 'Planejado') + '</span><a href="' + esc(m.link) + '" target="_blank" rel="noopener">Site da missão</a></div></article>';
    }).join('');
  }

  // ---------- início ----------
  function init() {
    hero(); missions(); buildCustomGrid(); buildScenarios(); buildCrops(); bind();
    var q = new URLSearchParams(location.search), loaded = false;
    function start() { syncControls(); render(); }
    if (q.get('s')) { try { st = sanitize(decodeState(q.get('s'))); loaded = true; } catch (e) { /* link inválido */ } }
    if (!loaded && q.get('plano')) {
      onUser(function once(u) {
        onUser.done = true;
        if (!u) { location.href = '/entrar.html?next=' + encodeURIComponent('/?plano=' + q.get('plano') + '#simulador'); return; }
        Api('GET', '/api/plans/' + encodeURIComponent(q.get('plano'))).then(function (j) { st = sanitize(j.plan.state); start(); persist(); }).catch(function (e) { start(); flash(e.message); });
      });
      start(); return;
    }
    if (!loaded) { try { var raw = localStorage.getItem('campo-state'); if (raw) st = sanitize(JSON.parse(raw)); } catch (e) { /* sem armazenamento */ } }
    start();
  }
  // Interface para as abas de histórico, projeção e tempo (extras.js).
  window.CampoApp = {
    state: function () { return st; }, reg: getReg, cache: function () { return cache; }, onRender: function (fn) { hooks.push(fn); },
    applyScenario: function (dT, dP) { st.dT = Math.max(0, Math.min(5, Math.round(dT * 2) / 2)); st.dP = Math.max(-40, Math.min(20, Math.round(dP / 5) * 5)); ['dT', 'dP'].forEach(function (k) { $(k).value = st[k]; }); change(); }
  };
  document.addEventListener('DOMContentLoaded', init);
})();
