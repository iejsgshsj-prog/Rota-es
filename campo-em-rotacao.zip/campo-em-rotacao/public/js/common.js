/* Utilidades compartilhadas: chamadas à API, menu do usuário, aviso de e-mail e service worker. */
(function () {
  'use strict';
  window.Api = function (method, url, body) {
    return fetch(url, {
      method: method, credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'campo' },
      body: body ? JSON.stringify(body) : undefined
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) { var e = new Error(j.error || 'Algo deu errado. Tente de novo.'); e.status = r.status; e.code = j.code; throw e; }
        return j;
      });
    });
  };
  window.esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  window.safeNext = function () {
    var n = new URLSearchParams(location.search).get('next') || '/';
    return (n.charAt(0) === '/' && n.charAt(1) !== '/' && n.indexOf('\\') < 0) ? n : '/';
  };
  var user = null, listeners = [];
  window.onUser = function (fn) { listeners.push(fn); if (user !== null) fn(user); };
  window.currentUser = function () { return user; };

  function renderNav() {
    var box = document.getElementById('navUser'), ban = document.getElementById('verifyBanner');
    if (box) {
      if (!user) {
        box.innerHTML = '<a class="btn ghost sm" href="/entrar.html?next=' + encodeURIComponent(location.pathname + location.search) + '">Entrar</a><a class="btn go sm" href="/entrar.html?modo=cadastro&next=' + encodeURIComponent(location.pathname + location.search) + '">Criar conta</a>';
      } else {
        box.innerHTML = '<details class="usermenu"><summary><span class="dot' + (user.verified ? '' : ' off') + '"></span>' + esc(user.name.split(' ')[0]) + '</summary><div class="pop"><a href="/conta.html">Minha conta e cenários</a><button type="button" id="logoutBtn">Sair</button></div></details>';
        document.getElementById('logoutBtn').onclick = function () { Api('POST', '/api/logout').then(function () { location.href = '/'; }); };
      }
    }
    if (ban) {
      if (user && !user.verified) {
        ban.hidden = false;
        ban.innerHTML = '<div class="inner"><span>Confirme seu e-mail (' + esc(user.email) + ') para salvar cenários.</span><button type="button" id="resendBtn">Reenviar e-mail</button><span id="resendMsg"></span></div>';
        document.getElementById('resendBtn').onclick = function () {
          var b = this; b.disabled = true;
          Api('POST', '/api/resend-verification').then(function (j) { document.getElementById('resendMsg').textContent = j.message || 'Enviado.'; })
            .catch(function (e) { document.getElementById('resendMsg').textContent = e.message; b.disabled = false; });
        };
      } else ban.hidden = true;
    }
  }
  window.refreshUser = function () {
    return Api('GET', '/api/me').then(function (j) { user = j.user; }).catch(function () { user = null; }).then(function () { renderNav(); listeners.forEach(function (fn) { fn(user); }); return user; });
  };
  document.addEventListener('DOMContentLoaded', function () {
    window.refreshUser();
    if ('serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('/sw.js').catch(function () {});
  });
})();
