(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  function msg(t, k) { var m = $('msg'); m.hidden = !t; m.textContent = t || ''; m.className = 'msg' + (k ? ' ' + k : ''); }
  function load() {
    Api('GET', '/api/plans').then(function (j) {
      if (!j.plans.length) { $('plist').innerHTML = '<p class="note">Nenhum cenário salvo ainda. No simulador, use "Salvar cenário".</p>'; return; }
      $('plist').innerHTML = j.plans.map(function (p) {
        return '<div class="prow"><div><b>' + esc(p.name) + '</b><small>' + new Date(p.createdAt).toLocaleString('pt-BR') + (p.summary ? ' · ' + esc(p.summary) : '') + '</small></div>' +
          '<div style="display:flex;gap:8px"><a class="btn ghost sm" href="/?plano=' + encodeURIComponent(p.id) + '#simulador">Abrir</a><button class="btn danger sm" data-del="' + esc(p.id) + '" type="button">Apagar</button></div></div>';
      }).join('');
    }).catch(function (e) { $('plist').innerHTML = '<p class="note">' + esc(e.message) + '</p>'; });
  }
  onUser(function (u) {
    if (!u) { location.replace('/entrar.html?next=/conta.html'); return; }
    $('who').textContent = u.name; $('mail').textContent = u.email + (u.verified ? ' · e-mail confirmado' : ' · e-mail ainda não confirmado');
    load();
  });
  $('plist').onclick = function (e) {
    var id = e.target.getAttribute && e.target.getAttribute('data-del'); if (!id) return;
    e.target.disabled = true;
    Api('DELETE', '/api/plans/' + encodeURIComponent(id)).then(load).catch(function (er) { msg(er.message, 'err'); e.target.disabled = false; });
  };
  $('fdel').onsubmit = function (e) {
    e.preventDefault();
    Api('DELETE', '/api/account', { password: $('dpw').value }).then(function () { location.href = '/'; }).catch(function (er) { msg(er.message, 'err'); });
  };
})();
