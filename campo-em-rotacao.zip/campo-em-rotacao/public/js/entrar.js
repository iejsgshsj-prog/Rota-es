(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var forms = { login: $('fLogin'), signup: $('fSignup'), forgot: $('fForgot') };
  function show(which) {
    Object.keys(forms).forEach(function (k) { forms[k].hidden = k !== which; });
    $('tabLogin').setAttribute('aria-selected', which === 'login');
    $('tabSignup').setAttribute('aria-selected', which === 'signup');
    $('ttl').textContent = which === 'signup' ? 'Criar conta' : (which === 'forgot' ? 'Redefinir senha' : 'Entrar');
    msg('');
  }
  function msg(text, kind) { var m = $('msg'); m.hidden = !text; m.textContent = text || ''; m.className = 'msg' + (kind ? ' ' + kind : ''); }
  $('tabLogin').onclick = function () { show('login'); };
  $('tabSignup').onclick = function () { show('signup'); };
  $('toForgot').onclick = function () { show('forgot'); };
  $('toLogin').onclick = function () { show('login'); };
  if (new URLSearchParams(location.search).get('modo') === 'cadastro') show('signup');
  Api('GET', '/api/config').then(function (c) { $('devHint').hidden = c.mail !== 'console'; }).catch(function () {});
  var signing = false;
  onUser(function (u) { if (u && !signing) location.replace(safeNext()); });

  function busy(btn, on) { btn.disabled = on; }
  forms.login.onsubmit = function (e) {
    e.preventDefault(); busy($('lgo'), true);
    Api('POST', '/api/login', { email: $('lemail').value, password: $('lpass').value })
      .then(function () { location.href = safeNext(); })
      .catch(function (er) { msg(er.message, 'err'); busy($('lgo'), false); });
  };
  forms.signup.onsubmit = function (e) {
    e.preventDefault(); busy($('sgo'), true);
    signing = true;
    Api('POST', '/api/signup', { name: $('sname').value, email: $('semail').value, password: $('spass').value })
      .then(function (j) {
        forms.signup.hidden = true;
        msg((j.message || 'Enviamos um link de confirmação.') + ' Abra o e-mail e toque em "Confirmar e-mail". Você já pode usar o simulador enquanto isso.', 'ok');
        var a = document.createElement('a'); a.className = 'btn go'; a.href = safeNext(); a.textContent = 'Ir para o simulador'; a.style.marginTop = '14px'; $('msg').after(a);
        window.refreshUser();
      })
      .catch(function (er) { signing = false; msg(er.message, 'err'); busy($('sgo'), false); });
  };
  forms.forgot.onsubmit = function (e) {
    e.preventDefault(); busy($('fgo'), true);
    Api('POST', '/api/forgot', { email: $('femail').value })
      .then(function (j) { msg(j.message, 'ok'); })
      .catch(function (er) { msg(er.message, 'err'); })
      .then(function () { busy($('fgo'), false); });
  };
})();
