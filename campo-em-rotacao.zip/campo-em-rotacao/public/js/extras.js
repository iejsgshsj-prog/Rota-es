/* Abas Histórico, Projeção e Tempo. Usa o simulador (CampoApp) e o modelo (Model). */
(function () {
  'use strict';
  var A = window.CampoApp, M = window.Model, MONTHS = M.MONTHS, CROPS = M.CROPS;
  if (!A || !M) return;
  var $ = function (id) { return document.getElementById(id); };
  var f = function (x) { return Math.round(x * 100); };
  var fmt = function (x, d) { return x.toLocaleString('pt-BR', { maximumFractionDigits: d == null ? 1 : d, minimumFractionDigits: d == null ? 0 : Math.min(d, 1) }); };
  var sgn = function (v, d, unit) { var k = Math.pow(10, d || 0), r = Math.round(v * k) / k, a = Math.abs(r); return (r > 0 ? '+' : (r < 0 ? '−' : '')) + fmt(a, d) + (unit || ''); };
  var cropName = function (id) { var c = M.byId(id); return c ? c.n.split(' (')[0] : id; };
  var MONO = 'IBM Plex Mono,monospace';
  var THIS_YEAR = new Date().getFullYear();

  var H = { key: null, data: null, demo: false, loading: false, err: null };
  var W = { key: null, data: null, loading: false, err: null };
  var active = 'resumo', sel = { len: 10, a: null, b: null }, projYear = 2035;

  function locKey() { var r = A.reg(); return (r.lat == null || r.lon == null) ? null : r.lat.toFixed(2) + ',' + r.lon.toFixed(2); }
  function kpi(cls, label, value, sub) { return '<div class="kpi ' + (cls || '') + '"><small>' + label + '</small><strong>' + value + '</strong><em>' + sub + '</em></div>'; }
  function txt(x, y, s, anchor) { return '<text x="' + x + '" y="' + y + '" text-anchor="' + (anchor || 'middle') + '" font-size="10" fill="var(--muted)" font-family="' + MONO + '">' + s + '</text>'; }
  function pill(delta, goodHigh) {
    var v = delta; if (goodHigh === false) v = -delta;
    if (v >= 2) return '<span class="chip pos">melhorou</span>';
    if (v <= -2) return '<span class="chip neg">piorou</span>';
    return '<span class="chip">estável</span>';
  }
  function evalOpts() { var o = JSON.parse(JSON.stringify(A.state())); o.irreg = 0; return o; }
  function lists() {
    var o = A.state(), c = A.cache(), a = c && c.plans && c.plans[0] ? c.plans[0].ids : null;
    return a ? [o.cur, a] : [o.cur];
  }
  function rotName(ids) { return ids.map(cropName).join(' → '); }

  // ---------- carregamento ----------
  function setMsg(prefix, text, showActions) {
    var m = $(prefix + 'Msg'); if (m) m.textContent = text || '';
    if (prefix === 'h') $('hActions').hidden = !showActions;
  }
  function paintHistState() {
    var has = !!H.data, show = function (id, on) { $(id).hidden = !on; };
    show('hBody', has); show('hMore', has); show('pBody', has); show('pMore', has);
    $('hDemo').hidden = !(has && H.demo);
    $('hSrc').textContent = has ? (H.demo ? 'SÉRIE SIMULADA' : H.source) : '';
    $('pSrc').textContent = has ? (H.demo ? 'SÉRIE SIMULADA' : H.source) : '';
    var msg = '', actions = false;
    if (!locKey()) msg = 'Informe a latitude e a longitude da gleba (ou escolha uma região) para ver os anos anteriores.';
    else if (H.loading) msg = 'Buscando a série mensal da NASA POWER para esta coordenada…';
    else if (H.err) { msg = H.err; actions = true; }
    setMsg('h', has ? '' : msg, actions && !has); setMsg('p', has ? '' : msg, false);
  }
  function ensureHist() {
    var key = locKey();
    if (!key) { H = { key: null, data: null, demo: false, loading: false, err: null }; paintHistState(); return; }
    if (H.key === key && (H.data || H.loading || H.err)) { paintHistState(); renderActive(); return; }
    H = { key: key, data: null, demo: false, loading: true, err: null }; sel.a = sel.b = null; paintHistState();
    var r = A.reg();
    window.Api('GET', '/api/history?lat=' + r.lat + '&lon=' + r.lon).then(function (j) {
      if (H.key !== key) return;
      H.loading = false; H.data = j.years; H.source = j.source; paintHistState(); renderActive();
    }).catch(function (e) { if (H.key !== key) return; H.loading = false; H.err = e.message; paintHistState(); });
  }
  function useDemo() {
    var r = A.reg(), seed = 0, k = H.key || '';
    for (var i = 0; i < k.length; i++) seed = (seed * 31 + k.charCodeAt(i)) >>> 0;
    H.data = M.demoSeries(r, 1991, THIS_YEAR - 1, seed || 7); H.demo = true; H.err = null; H.source = 'simulada'; sel.a = sel.b = null; paintHistState(); renderActive();
  }
  function ensureWx() {
    var key = locKey();
    if (!key) { $('wBody').hidden = $('wMore').hidden = true; $('wMsg').textContent = 'Informe a latitude e a longitude da gleba para ver o tempo.'; return; }
    if (W.key === key && (W.data || W.loading || W.err)) { paintWxState(); if (W.data) renderWx(); return; }
    W = { key: key, data: null, loading: true, err: null }; paintWxState();
    var r = A.reg();
    window.Api('GET', '/api/weather?lat=' + r.lat + '&lon=' + r.lon).then(function (j) {
      if (W.key !== key) return; W.loading = false; W.data = j; paintWxState(); renderWx();
    }).catch(function (e) { if (W.key !== key) return; W.loading = false; W.err = e.message; paintWxState(); });
  }
  function paintWxState() {
    var has = !!W.data; $('wBody').hidden = !has; $('wMore').hidden = !has;
    $('wSrc').textContent = has ? W.data.source + ' · atualizado ' + new Date(W.data.fetchedAt).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '';
    $('wMsg').textContent = has ? '' : (W.loading ? 'Buscando previsão e últimos 30 dias…' : (W.err || ''));
  }
  function renderActive() { if (active === 'hist') renderHist(); else if (active === 'proj') renderProj(); else if (active === 'tempo' && W.data) renderWx(); }

  // ---------- gráficos ----------
  function niceRange(lo, hi, step) { return [Math.floor(lo / step) * step, Math.ceil(hi / step) * step]; }
  function chartScores(el, sc, series, bands) {
    var Wd = 640, Ht = 250, L = 40, R = 16, T = 14, B = 26, pw = Wd - L - R, ph = Ht - T - B, x0 = sc[0].year, x1 = sc[sc.length - 1].year;
    var xs = function (yr) { return L + (yr - x0) / ((x1 - x0) || 1) * pw; }, step = pw / ((x1 - x0) || 1);
    var all = []; series.forEach(function (s) { all = all.concat(s.v); });
    var r = niceRange(Math.max(0, Math.min.apply(null, all) - 5), Math.min(100, Math.max.apply(null, all) + 5), 10), lo = r[0], hi = Math.max(r[1], lo + 10);
    var ys = function (v) { return T + ph - (v - lo) / (hi - lo) * ph; }, s = '', i;
    bands.forEach(function (b) { s += '<rect x="' + (xs(b[0]) - step / 2) + '" y="' + T + '" width="' + ((b[1] - b[0]) * step + step) + '" height="' + ph + '" fill="var(--sky)" opacity="0.14"/>' + txt(xs((b[0] + b[1]) / 2), T + 10, b[2]); });
    for (i = 0; i <= 5; i++) { var gv = lo + (hi - lo) * i / 5, gy = ys(gv); s += '<line x1="' + L + '" x2="' + (Wd - R) + '" y1="' + gy + '" y2="' + gy + '" stroke="var(--line)"/>' + txt(L - 6, gy + 4, Math.round(gv), 'end'); }
    for (var yr = x0; yr <= x1; yr++) if (yr % 5 === 0) s += txt(xs(yr), Ht - 8, yr);
    var years = sc.map(function (q) { return q.year; });
    series.forEach(function (se) {
      s += '<polyline fill="none" stroke="' + se.color + '" stroke-width="2" stroke-linejoin="round" points="' + sc.map(function (q, k) { return xs(q.year) + ',' + ys(se.v[k]); }).join(' ') + '"/>';
      var fit = M.linfit(years, se.v), a = fit.intercept + fit.slope * x0, b = fit.intercept + fit.slope * x1;
      s += '<line x1="' + xs(x0) + '" y1="' + ys(a) + '" x2="' + xs(x1) + '" y2="' + ys(b) + '" stroke="' + se.color + '" stroke-width="1.6" stroke-dasharray="5 4" opacity="0.9"/>';
    });
    el.innerHTML = s;
  }
  function chartCombo(el, years, T, P) {
    var Wd = 640, Ht = 250, L = 46, R = 46, Tp = 16, B = 28, pw = Wd - L - R, ph = Ht - Tp - B, n = years.length, bw = pw / n;
    var pmax = Math.ceil(Math.max.apply(null, P) * 1.1 / 200) * 200 || 200, tr = niceRange(Math.min.apply(null, T) - 1, Math.max.apply(null, T) + 1, 1), tlo = tr[0], thi = Math.max(tr[1], tlo + 2);
    var y = function (v) { return Tp + ph - v / pmax * ph; }, yt = function (v) { return Tp + ph - (v - tlo) / (thi - tlo) * ph; }, s = '', i;
    for (i = 0; i <= 4; i++) { var gy = Tp + ph * (1 - i / 4); s += '<line x1="' + L + '" x2="' + (Wd - R) + '" y1="' + gy + '" y2="' + gy + '" stroke="var(--line)"/>' + txt(L - 6, gy + 4, Math.round(pmax * i / 4), 'end') + txt(Wd - R + 6, gy + 4, fmt(tlo + (thi - tlo) * i / 4, 1) + '°', 'start'); }
    s += txt(L, 10, 'mm/ano', 'start');
    years.forEach(function (yy, k) {
      s += '<rect x="' + (L + k * bw + bw * 0.12) + '" y="' + y(P[k]) + '" width="' + (bw * 0.76) + '" height="' + (Tp + ph - y(P[k])) + '" fill="var(--sky)" opacity="0.55"/>';
      if (yy.year % 5 === 0) s += txt(L + k * bw + bw / 2, Ht - 8, yy.year);
    });
    s += '<polyline fill="none" stroke="var(--soil)" stroke-width="2.2" stroke-linejoin="round" points="' + T.map(function (v, k) { return (L + k * bw + bw / 2) + ',' + yt(v); }).join(' ') + '"/>';
    var xs = years.map(function (yy) { return yy.year; }), fT = M.linfit(xs, T), fP = M.linfit(xs, P), x0 = xs[0], x1 = xs[n - 1];
    s += '<line x1="' + (L + bw / 2) + '" x2="' + (L + (n - 0.5) * bw) + '" y1="' + yt(fT.intercept + fT.slope * x0) + '" y2="' + yt(fT.intercept + fT.slope * x1) + '" stroke="var(--soil)" stroke-dasharray="5 4" stroke-width="1.6"/>';
    s += '<line x1="' + (L + bw / 2) + '" x2="' + (L + (n - 0.5) * bw) + '" y1="' + y(fP.intercept + fP.slope * x0) + '" y2="' + y(fP.intercept + fP.slope * x1) + '" stroke="var(--fg)" stroke-dasharray="5 4" stroke-width="1.4" opacity="0.8"/>';
    el.innerHTML = s;
  }
  function chartTrend(el, xs, ys, fit, target, unit, color, dec) {
    var Wd = 640, Ht = 250, L = 52, R = 22, T = 16, B = 28, pw = Wd - L - R, ph = Ht - T - B, x0 = xs[0], xmax = Math.max(xs[xs.length - 1], target.year);
    var all = ys.concat([target.val + target.sd, target.val - target.sd]), pad = (Math.max.apply(null, all) - Math.min.apply(null, all)) * 0.08;
    var lo = Math.min.apply(null, all) - pad, hi = Math.max.apply(null, all) + pad;
    var X = function (yr) { return L + (yr - x0) / (xmax - x0) * pw; }, Y = function (v) { return T + ph - (v - lo) / (hi - lo) * ph; }, s = '', i;
    for (i = 0; i <= 4; i++) { var gv = lo + (hi - lo) * i / 4, gy = Y(gv); s += '<line x1="' + L + '" x2="' + (Wd - R) + '" y1="' + gy + '" y2="' + gy + '" stroke="var(--line)"/>' + txt(L - 6, gy + 4, fmt(gv, dec), 'end'); }
    s += txt(L, 10, unit, 'start');
    for (var yr = Math.ceil(x0 / 5) * 5; yr <= xmax; yr += 5) s += txt(X(yr), Ht - 8, yr);
    s += '<rect x="' + X(xs[xs.length - 1]) + '" y="' + T + '" width="' + (X(xmax) - X(xs[xs.length - 1])) + '" height="' + ph + '" fill="var(--surface2)" opacity="0.7"/>';
    s += '<polyline fill="none" stroke="' + color + '" stroke-width="1.8" stroke-linejoin="round" points="' + xs.map(function (yy, k) { return X(yy) + ',' + Y(ys[k]); }).join(' ') + '"/>';
    xs.forEach(function (yy, k) { s += '<circle cx="' + X(yy) + '" cy="' + Y(ys[k]) + '" r="2.4" fill="' + color + '"/>'; });
    s += '<line x1="' + X(x0) + '" y1="' + Y(fit.intercept + fit.slope * x0) + '" x2="' + X(xmax) + '" y2="' + Y(fit.intercept + fit.slope * xmax) + '" stroke="var(--fg)" stroke-width="1.6" stroke-dasharray="5 4"/>';
    var tx = X(target.year);
    s += '<line x1="' + tx + '" x2="' + tx + '" y1="' + Y(target.val + target.sd) + '" y2="' + Y(target.val - target.sd) + '" stroke="var(--warn)" stroke-width="2"/><circle cx="' + tx + '" cy="' + Y(target.val) + '" r="4.5" fill="var(--warn)"/>';
    s += txt(Math.min(tx, Wd - 40), Math.max(T + 10, Y(target.val + target.sd) - 6), target.year + ': ' + fmt(target.val, dec), 'end');
    el.innerHTML = s;
  }

  // ---------- histórico ----------
  var memo = { k: '', v: null };
  function scoresFor(years) {
    var o = A.state(), L = lists(), k = JSON.stringify([H.key, H.demo, years.length, L, o.awc, o.irrig, o.noTill, o.price, o.wW, o.wS, o.wI, o.wR, o.allowed, o.years]);
    if (memo.k !== k) memo = { k: k, v: M.yearScores(years, A.reg(), o, L) };
    return memo.v;
  }
  function buildPeriodSelects(years) {
    var first = years[0].year, last = years[years.length - 1].year, len = sel.len, opts = '', lastStart = Math.max(first, last - len + 1);
    if (sel.a == null || sel.a > lastStart || sel.a < first) sel.a = first;
    if (sel.b == null || sel.b > lastStart || sel.b < first) sel.b = lastStart;
    for (var y = first; y <= lastStart; y++) opts += '<option value="' + y + '">' + y + '–' + (y + len - 1) + '</option>';
    $('hA').innerHTML = opts; $('hB').innerHTML = opts; $('hA').value = sel.a; $('hB').value = sel.b; $('hLen').value = len;
  }
  function renderHist() {
    if (!H.data) return;
    var years = H.data, reg = A.reg(), o = evalOpts(), L = lists(), len = sel.len;
    if (!$('hA').options.length || +$('hA').dataset.n !== years.length || +$('hA').dataset.len !== len) { buildPeriodSelects(years); $('hA').dataset.n = years.length; $('hA').dataset.len = len; }
    var aY = +$('hA').value, bY = +$('hB').value, regA = M.periodReg(years, aY, aY + len - 1, reg), regB = M.periodReg(years, bY, bY + len - 1, reg);
    if (!regA || !regB) return;
    var stA = M.annualStats(regA), stB = M.annualStats(regB), sc = scoresFor(years);
    var inP = function (q, y0) { return q.year >= y0 && q.year < y0 + len; };
    var avg = function (k, y0) { var v = sc.filter(function (q) { return inP(q, y0); }).map(function (q) { return q.rots[k].total * 100; }); return v.length ? M.mean(v) : 0; };
    var cards = '';
    cards += kpi('', 'Temperatura média', fmt(stB.meanT, 1) + ' °C', 'A ' + fmt(stA.meanT, 1) + ' → B ' + fmt(stB.meanT, 1) + ' (' + sgn(stB.meanT - stA.meanT, 1, ' °C') + ')');
    cards += kpi('', 'Chuva anual', Math.round(stB.totalP) + ' mm', 'A ' + Math.round(stA.totalP) + ' → B ' + Math.round(stB.totalP) + ' (' + sgn((stB.totalP / stA.totalP - 1) * 100, 0, '%') + ')');
    cards += kpi(stB.dryMonths > stA.dryMonths ? 'bad' : (stB.dryMonths < stA.dryMonths ? 'good' : ''), 'Meses secos (&lt; 50 mm)', stB.dryMonths, 'A ' + stA.dryMonths + ' → B ' + stB.dryMonths);
    cards += kpi(stB.balance < stA.balance - 20 ? 'bad' : (stB.balance > stA.balance + 20 ? 'good' : ''), 'Saldo de água no ano', sgn(stB.balance, 0, ' mm'), 'chuva útil − ETo · A ' + sgn(stA.balance, 0) + ' → B ' + sgn(stB.balance, 0));
    var dc = avg(0, bY) - avg(0, aY);
    cards += kpi(dc >= 2 ? 'good' : (dc <= -2 ? 'bad' : ''), 'Sua rotação (nota média)', Math.round(avg(0, bY)), 'A ' + Math.round(avg(0, aY)) + ' → B ' + Math.round(avg(0, bY)) + ' (' + sgn(dc, 0, ' pts') + ')');
    if (L.length > 1) { var dp = avg(1, bY) - avg(1, aY); cards += kpi(dp >= 2 ? 'good' : (dp <= -2 ? 'bad' : ''), 'Plano A (nota média)', Math.round(avg(1, bY)), 'A ' + Math.round(avg(1, aY)) + ' → B ' + Math.round(avg(1, bY)) + ' (' + sgn(dp, 0, ' pts') + ')'); }
    $('hKpis').innerHTML = cards;
    // gráficos
    var series = [{ v: sc.map(function (q) { return q.rots[0].total * 100; }), color: 'var(--muted)' }];
    if (L.length > 1) series.push({ v: sc.map(function (q) { return q.rots[1].total * 100; }), color: 'var(--field)' });
    chartScores($('hChart1'), sc, series, [[aY, aY + len - 1, 'A'], [bY, bY + len - 1, 'B']]);
    chartCombo($('hChart2'), years, years.map(function (y) { return M.mean(y.t); }), years.map(function (y) { return M.sum(y.p); }));
    // culturas
    var SA = M.suitAll(regA, o, 0, 0), SB = M.suitAll(regB, o, 0, 0), st = A.state();
    var h = '<thead><tr><th>Item</th><th class="n">Período A</th><th class="n">Período B</th><th class="n">Mudança</th><th>Situação</th><th>Melhor mês de plantio</th></tr></thead><tbody>';
    L.forEach(function (ids, k) {
      var a = M.scoreRot(ids, SA, o).total * 100, b = M.scoreRot(ids, SB, o).total * 100;
      h += '<tr class="sub"><td><b>' + (k === 0 ? 'Sua rotação' : 'Plano A') + '</b><br><span class="note">' + esc(rotName(ids)) + '</span></td><td class="n">' + Math.round(a) + '</td><td class="n">' + Math.round(b) + '</td><td class="n">' + sgn(b - a, 0, ' pts') + '</td><td>' + pill(b - a) + '</td><td></td></tr>';
    });
    var rows = CROPS.filter(function (c) { return st.allowed.indexOf(c.id) >= 0; }).map(function (c) { return { c: c, a: SA[c.id], b: SB[c.id] }; }).sort(function (x, y) { return (y.b.best - y.a.best) - (x.b.best - x.a.best); });
    rows.forEach(function (r) {
      var d = (r.b.best - r.a.best) * 100;
      h += '<tr><td>' + esc(cropName(r.c.id)) + '</td><td class="n">' + f(r.a.best) + '</td><td class="n">' + f(r.b.best) + '</td><td class="n">' + sgn(d, 0, ' pts') + '</td><td>' + pill(d) + '</td><td>' + (r.a.start === r.b.start ? MONTHS[r.a.start] : MONTHS[r.a.start] + ' → ' + MONTHS[r.b.start]) + '</td></tr>';
    });
    $('hTbl').innerHTML = h + '</tbody>';
    // anos difíceis e favoráveis
    var ord = sc.slice().sort(function (p, q) { return p.rots[0].total - q.rots[0].total; }), worst = ord.slice(0, 4), best = ord.slice(-3).reverse();
    function why(q) {
      var x = q.rots[0].cs.slice().sort(function (p1, p2) { return p1.best - p2.best; })[0];
      if (!x) return '';
      var bits = [];
      if (x.frostN > 0 && x.frostF < 0.9) bits.push('geada');
      if (x.heatN > 0 && x.heatF < 0.9) bits.push('calor');
      if (x.wf < 0.9) bits.push('falta de água (' + Math.round(x.deficit) + ' mm de déficit)');
      if (x.best >= 0.9 && !bits.length) return 'sem fator dominante';
      if (!bits.length) bits.push('temperatura fora da faixa ideal');
      return esc(cropName(x.c.id)) + ': ' + bits.join(', ');
    }
    var w = '<thead><tr><th>Ano</th><th class="n">Sua rotação</th>' + (L.length > 1 ? '<th class="n">Plano A</th>' : '') + '<th>Culpado principal</th><th class="n">Chuva</th><th class="n">Temp.</th></tr></thead><tbody>';
    function wrow(q, cls) { return '<tr class="' + cls + '"><td><b>' + q.year + '</b></td><td class="n">' + f(q.rots[0].total) + '</td>' + (L.length > 1 ? '<td class="n">' + f(q.rots[1].total) + '</td>' : '') + '<td>' + (cls === 'bad' ? why(q) : '') + '</td><td class="n">' + Math.round(q.stats.totalP) + ' mm</td><td class="n">' + fmt(q.stats.meanT, 1) + ' °C</td></tr>'; }
    w += worst.map(function (q) { return wrow(q, 'bad'); }).join('') + best.map(function (q) { return wrow(q, 'good'); }).join('');
    $('hWorst').innerHTML = w + '</tbody>';
    var wins = L.length > 1 ? sc.filter(function (q) { return q.rots[1].total > q.rots[0].total; }).length : 0;
    $('hWorstNote').textContent = L.length > 1 ? 'O Plano A teria ido melhor em ' + wins + ' de ' + sc.length + ' anos.' : '';
    // faixa
    var S = '<thead><tr><th></th>' + sc.map(function (q) { return '<th>' + (q.year % 5 === 0 ? String(q.year).slice(2) : '') + '</th>'; }).join('') + '</tr></thead><tbody>';
    rows.sort(function (x, y) { return CROPS.indexOf(x.c) - CROPS.indexOf(y.c); }).forEach(function (r) {
      S += '<tr><td>' + esc(cropName(r.c.id)) + '</td>' + sc.map(function (q) { var s = q.S[r.c.id]; return '<td class="c" style="--v:' + (s.best * 0.8).toFixed(2) + '" title="' + q.year + ' · ' + esc(cropName(r.c.id)) + ': ' + f(s.best) + ', plantio em ' + MONTHS[s.start] + '"></td>'; }).join('') + '</tr>';
    });
    $('hStrip').innerHTML = S + '</tbody>';
  }

  // ---------- projeção ----------
  function renderProj() {
    if (!H.data) return;
    var years = H.data, reg = A.reg(), o = evalOpts(), L = lists(), st = A.state();
    var last = years[years.length - 1].year; $('pYear').min = last + 1; if (projYear <= last) projYear = Math.max(last + 5, 2030); $('pYear').value = projYear; $('pYearO').textContent = projYear;
    var P = M.project(years, projYear), tr = P.tr, base10 = M.periodReg(years, P.y0, P.last, reg), baseS = M.annualStats(base10);
    var confT = Math.abs(tr.t.t) >= 2 ? 'distinguível do ruído' : 'incerta (próxima do ruído)', confP = Math.abs(tr.p.t) >= 2 ? 'distinguível do ruído' : 'incerta (próxima do ruído)';
    var meanP = P.meanP, pDec = meanP ? tr.p.slope * 10 / meanP * 100 : 0;
    $('pKpis').innerHTML =
      kpi(tr.t.slope > 0 ? 'bad' : '', 'Temperatura por década', sgn(tr.t.slope * 10, 2, ' °C'), 'tendência ' + confT) +
      kpi(pDec < 0 ? 'bad' : '', 'Chuva por década', sgn(pDec, 1, '%'), 'tendência ' + confP) +
      kpi('', 'Em ' + projYear, fmt(baseS.meanT + P.dT, 1) + ' °C · ' + Math.round(baseS.totalP * (1 + P.dP)) + ' mm', 'hoje (média ' + P.y0 + '–' + P.last + '): ' + fmt(baseS.meanT, 1) + ' °C · ' + Math.round(baseS.totalP) + ' mm') +
      kpi('', 'Variação entre anos', '±' + fmt(P.sdT, 1) + ' °C · ±' + fmt(P.sdP * 100, 0) + '%', 'desvio-padrão em torno da tendência');
    chartTrend($('pChart1'), tr.xs, tr.T, tr.t, { year: projYear, val: baseS.meanT + P.dT, sd: P.sdT }, '°C', 'var(--soil)', 1);
    chartTrend($('pChart2'), tr.xs, tr.P, tr.p, { year: projYear, val: baseS.totalP * (1 + P.dP), sd: P.sdP * meanP }, 'mm/ano', 'var(--sky)', 0);
    // rotações sob cada caso
    var S0 = M.suitAll(base10, o, 0, 0), t = '<thead><tr><th>Situação em ' + projYear + '</th><th class="n">Temp.</th><th class="n">Chuva</th>' + L.map(function (ids, k) { return '<th class="n">' + (k === 0 ? 'Sua rotação' : 'Plano A') + '</th>'; }).join('') + '</tr></thead><tbody>';
    t += '<tr class="sub"><td>Média ' + P.y0 + '–' + P.last + ' (referência)</td><td class="n">—</td><td class="n">—</td>' + L.map(function (ids) { return '<td class="n">' + f(M.scoreRot(ids, S0, o).total) + '</td>'; }).join('') + '</tr>';
    var central = null;
    P.cases.forEach(function (c) {
      var rc = M.applyDelta(base10, c.dT, c.dP), S = M.suitAll(rc, o, 0, 0); if (c.id === 'central') central = S;
      t += '<tr><td><b>' + c.n + '</b></td><td class="n">' + sgn(c.dT, 1, ' °C') + '</td><td class="n">' + sgn(c.dP * 100, 0, '%') + '</td>' + L.map(function (ids) {
        var v = M.scoreRot(ids, S, o).total * 100, b0 = M.scoreRot(ids, S0, o).total * 100, dd = Math.round(v) - Math.round(b0);
        return '<td class="n">' + Math.round(v) + ' <span class="' + (dd > 0 ? 'up' : (dd < 0 ? 'dn' : '')) + '">(' + sgn(dd, 0) + ')</span></td>';
      }).join('') + '</tr>';
    });
    $('pTbl').innerHTML = t + '</tbody>';
    // culturas
    var rows = CROPS.filter(function (c) { return st.allowed.indexOf(c.id) >= 0; }).map(function (c) { return { c: c, a: S0[c.id], b: central[c.id] }; }).sort(function (x, y) { return (y.b.best - y.a.best) - (x.b.best - x.a.best); });
    var h = '<thead><tr><th>Cultura</th><th class="n">Referência</th><th class="n">Em ' + projYear + '</th><th class="n">Mudança</th><th>Situação</th><th>Melhor mês</th></tr></thead><tbody>';
    rows.forEach(function (r) { var d = (r.b.best - r.a.best) * 100; h += '<tr><td>' + esc(cropName(r.c.id)) + '</td><td class="n">' + f(r.a.best) + '</td><td class="n">' + f(r.b.best) + '</td><td class="n">' + sgn(d, 0, ' pts') + '</td><td>' + pill(d) + '</td><td>' + (r.a.start === r.b.start ? MONTHS[r.a.start] : MONTHS[r.a.start] + ' → ' + MONTHS[r.b.start]) + '</td></tr>'; });
    $('pCrops').innerHTML = h + '</tbody>';
    // valores para aplicar no simulador: diferença contra a média 1991–2020 da própria série
    var ref = M.periodReg(years, 1991, 2020, reg) || M.periodReg(years, years[0].year, last, reg), rs = M.annualStats(ref);
    P.apply = { dT: (baseS.meanT + P.dT) - rs.meanT, dP: ((baseS.totalP * (1 + P.dP)) / rs.totalP - 1) * 100 };
    $('pApply').dataset.dt = P.apply.dT; $('pApply').dataset.dp = P.apply.dP;
  }

  // ---------- tempo ----------
  function renderWx() {
    var d = W.data, reg = A.reg(), a = M.assessWeather(d.days, d.today, reg), o = A.state();
    var pct = function (r) { return r == null ? '' : ' (' + Math.round(r * 100) + '% da normal)'; };
    $('wKpis').innerHTML =
      kpi(a.ratioPast != null && a.ratioPast < 0.6 ? 'bad' : '', 'Chuva nos últimos ' + a.nPast + ' dias', Math.round(a.rainPast) + ' mm', 'normal ' + Math.round(a.normPast) + ' mm' + pct(a.ratioPast)) +
      kpi(a.ratioFut != null && a.ratioFut < 0.6 ? 'bad' : '', 'Chuva prevista (' + a.nFut + ' dias)', Math.round(a.rainFut) + ' mm', 'normal ' + Math.round(a.normFut) + ' mm' + pct(a.ratioFut)) +
      kpi((a.rainPast - a.etoPast) < -40 ? 'bad' : '', 'Saldo de água, 30 dias', sgn(a.rainPast - a.etoPast, 0, ' mm'), 'chuva − evapotranspiração (ETo ' + Math.round(a.etoPast) + ' mm)') +
      kpi(a.hotDays >= 3 ? 'bad' : '', 'Máxima prevista', fmt(a.tmaxFut, 1) + ' °C', a.hotDays + ' dia(s) com 35 °C ou mais') +
      kpi(a.frostNights > 0 ? 'bad' : '', 'Mínima prevista', fmt(a.tminFut, 1) + ' °C', a.coldNights + ' noite(s) com 3 °C ou menos') +
      kpi(a.dryRun >= 8 ? 'bad' : '', 'Maior sequência seca', a.dryRun + ' dias', 'na previsão, dias com menos de 1 mm');
    chartWx($('wChart'), d);
    var al = [];
    if (a.ratioPast != null) {
      if (a.ratioPast < 0.6) al.push(['warn', 'Os últimos ' + a.nPast + ' dias foram secos: ' + Math.round(a.rainPast) + ' mm contra ' + Math.round(a.normPast) + ' mm normais. O solo tende a chegar ao plantio com menos reserva do que o simulador assume. Considere irrigação suplementar ou culturas mais tolerantes à seca (' + CROPS.filter(function (c) { return c.tol >= 0.7 && o.allowed.indexOf(c.id) >= 0; }).map(function (c) { return cropName(c.id).toLowerCase(); }).join(', ') + ').']);
      else if (a.ratioPast > 1.4) al.push(['info', 'Os últimos ' + a.nPast + ' dias foram chuvosos: ' + Math.round(a.rainPast) + ' mm contra ' + Math.round(a.normPast) + ' mm normais. A reserva de água deve estar acima da média, o que ajuda a germinação. O risco passa a ser solo encharcado, atraso de plantio e doenças.']);
      else al.push(['good', 'A chuva dos últimos ' + a.nPast + ' dias ficou perto do normal (' + Math.round(a.rainPast) + ' mm contra ' + Math.round(a.normPast) + ' mm). A reserva de água inicial deve estar próxima da média usada no simulador.']);
    }
    if (a.ratioFut != null) {
      if (a.ratioFut < 0.6) al.push(['warn', 'A previsão traz pouca chuva: ' + Math.round(a.rainFut) + ' mm contra ' + Math.round(a.normFut) + ' mm normais nos próximos ' + a.nFut + ' dias. Se a chuva fraca coincidir com a janela de plantio, o risco de falha de germinação e de replantio aumenta.']);
      else if (a.ratioFut > 1.4) al.push(['info', 'A previsão traz muita chuva: ' + Math.round(a.rainFut) + ' mm contra ' + Math.round(a.normFut) + ' mm normais. Boa para repor reserva. Atenção a erosão e a janelas de trabalho no campo.']);
      else al.push(['good', 'A chuva prevista (' + Math.round(a.rainFut) + ' mm) está perto do normal para o período.']);
    }
    if (a.dryRun >= 8) al.push(['warn', 'A previsão tem ' + a.dryRun + ' dias secos seguidos, o que pode formar um veranico em fase sensível da cultura.']);
    if (a.hotDays >= 3) al.push(['warn', a.hotDays + ' dias com máxima de 35 °C ou mais (pico de ' + fmt(a.tmaxFut, 1) + ' °C). Calor nessa faixa já prejudica floração de várias culturas.']);
    if (a.frostNights > 0) al.push(['warn', 'Previsão de geada (mínima de ' + fmt(a.tminFut, 1) + ' °C). Evite semear culturas sensíveis até passar.']);
    else if (a.coldNights > 0) al.push(['info', a.coldNights + ' noite(s) com 3 °C ou menos: risco de geada fraca em baixadas.']);
    if (!al.length) al.push(['good', 'Sem alertas relevantes na janela observada.']);
    $('wAlerts').innerHTML = al.map(function (x) { return '<li class="al ' + x[0] + '"><span class="dot"></span><span>' + esc(x[1]) + '</span></li>'; }).join('');
    var month = parseInt(d.today.slice(5, 7), 10) - 1, S = M.suitAll(reg, evalOpts(), 0, 0), adv = M.plantingAdvice(S, o.allowed, month, a);
    adv.sort(function (p, q) { return q.here - p.here; });
    $('wAdvNote').textContent = 'Mês atual: ' + MONTHS[month] + ' · clima normal da gleba + previsão';
    var t = '<thead><tr><th>Cultura</th><th>Aptidão em ' + MONTHS[month] + '</th><th>Situação</th><th>Motivo</th></tr></thead><tbody>';
    adv.forEach(function (r) {
      var s = S[r.id], status, why = '';
      if (!r.window) { status = '<span class="chip">fora da janela</span>'; why = 'Melhor mês de plantio no clima normal: ' + MONTHS[s.start] + '.'; }
      else if (r.ok) { status = '<span class="chip pos">janela favorável</span>'; why = 'A previsão não contraria o plantio.'; }
      else { status = '<span class="chip neg">esperar</span>'; why = r.why.join('; ') + '.'; }
      t += '<tr' + (r.window ? '' : ' style="opacity:.6"') + '><td>' + esc(cropName(r.id)) + '</td><td><span class="mini"><i style="width:' + f(r.here) + '%"></i></span> <span class="mono">' + f(r.here) + '</span></td><td>' + status + '</td><td>' + esc(why) + '</td></tr>';
    });
    $('wAdv').innerHTML = t + '</tbody>';
  }
  function chartWx(el, d) {
    var days = d.days, n = days.length, Wd = 640, Ht = 260, L = 44, R = 44, T = 16, B = 30, pw = Wd - L - R, ph = Ht - T - B, bw = pw / n;
    var rmax = Math.max(10, Math.ceil(Math.max.apply(null, days.map(function (x) { return x.rain; })) / 5) * 5);
    var temps = []; days.forEach(function (x) { if (x.tmax != null) temps.push(x.tmax); if (x.tmin != null) temps.push(x.tmin); });
    var tr = niceRange(Math.min.apply(null, temps) - 1, Math.max.apply(null, temps) + 1, 5), tlo = tr[0], thi = Math.max(tr[1], tlo + 5);
    var y = function (v) { return T + ph - v / rmax * ph; }, yt = function (v) { return T + ph - (v - tlo) / (thi - tlo) * ph; }, s = '', i;
    for (i = 0; i <= 4; i++) { var gy = T + ph * (1 - i / 4); s += '<line x1="' + L + '" x2="' + (Wd - R) + '" y1="' + gy + '" y2="' + gy + '" stroke="var(--line)"/>' + txt(L - 6, gy + 4, fmt(rmax * i / 4, rmax % 4 ? 1 : 0), 'end') + txt(Wd - R + 6, gy + 4, Math.round(tlo + (thi - tlo) * i / 4) + '°', 'start'); }
    s += txt(L, 10, 'mm/dia', 'start');
    var ti = days.findIndex(function (x) { return x.date >= d.today; }); if (ti < 0) ti = n;
    days.forEach(function (x, k) {
      var past = k < ti, bx = L + k * bw + bw * 0.12;
      s += '<rect x="' + bx + '" y="' + y(x.rain) + '" width="' + (bw * 0.76) + '" height="' + Math.max(0, T + ph - y(x.rain)) + '" fill="var(--sky)"' + (past ? '' : ' fill-opacity="0.3" stroke="var(--sky)" stroke-width="1"') + '/>';
      if (k % 7 === 0) s += txt(L + k * bw + bw / 2, Ht - 10, x.date.slice(8, 10) + '/' + x.date.slice(5, 7));
    });
    function line(key, col) { var pts = []; days.forEach(function (x, k) { if (x[key] != null) pts.push((L + k * bw + bw / 2) + ',' + yt(x[key])); }); return '<polyline fill="none" stroke="' + col + '" stroke-width="2" stroke-linejoin="round" points="' + pts.join(' ') + '"/>'; }
    s += line('tmax', 'var(--soil)') + line('tmin', 'var(--muted)');
    var tx = L + ti * bw; s += '<line x1="' + tx + '" x2="' + tx + '" y1="' + T + '" y2="' + (T + ph) + '" stroke="var(--fg)" stroke-dasharray="4 3"/>' + txt(tx - 4, T + 10, 'passado', 'end') + txt(tx + 4, T + 10, 'previsão', 'start');
    el.innerHTML = s;
  }

  // ---------- eventos ----------
  function bind() {
    document.querySelectorAll('.tabs button').forEach(function (b) {
      b.addEventListener('click', function () {
        active = b.dataset.tab;
        if (active === 'hist' || active === 'proj') ensureHist(); else if (active === 'tempo') ensureWx();
      });
    });
    $('hRetry').onclick = function () { H.key = null; H.err = null; ensureHist(); };
    $('hDemoBtn').onclick = useDemo;
    $('hLen').onchange = function () { sel.len = +this.value; sel.a = sel.b = null; $('hA').innerHTML = ''; renderHist(); };
    $('hA').onchange = function () { sel.a = +this.value; renderHist(); };
    $('hB').onchange = function () { sel.b = +this.value; renderHist(); };
    $('pYear').oninput = function () { projYear = +this.value; $('pApplyMsg').textContent = ''; renderProj(); };
    $('pApply').onclick = function () {
      A.applyScenario(parseFloat(this.dataset.dt), parseFloat(this.dataset.dp));
      var st = A.state(); $('pApplyMsg').textContent = 'Cenário do simulador ajustado para +' + fmt(st.dT, 1) + ' °C e ' + (st.dP > 0 ? '+' : '') + st.dP + '% de chuva (arredondado aos passos dos controles).';
    };
    A.onRender(function () {
      var key = locKey();
      if (H.key && H.key !== key) H = { key: null, data: null, demo: false, loading: false, err: null };
      if (W.key && W.key !== key) W = { key: null, data: null, loading: false, err: null };
      if (active === 'hist' || active === 'proj') ensureHist(); else if (active === 'tempo') ensureWx();
    });
  }
  document.addEventListener('DOMContentLoaded', function () { bind(); paintHistState(); });
})();
