/* Modelo agronômico simplificado do Campo em Rotação.
 * Roda no navegador e no Node (testes). Sem dependências.
 * Água: necessidade da cultura = Kc x ETo (Hargreaves-Samani) no ciclo.
 * Temperatura: faixa ótima, estresse por calor (Tmax) e geada (Tmin).
 * Todos os parâmetros são médias de referência para exploração, não recomendação agronômica. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Model = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var MONTHS = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  var MDAYS = [31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  var MID_DOY = [15, 46, 74, 105, 135, 166, 196, 227, 258, 288, 319, 349];

  // Climatologia mensal aproximada de referência (°C e mm/mês). dtr = amplitude térmica diária média.
  var REGIONS = {
    sorriso: { n: 'Sorriso, Mato Grosso, Brasil', lat: -12.5, lon: -55.7, dtr: 10, t: [25, 25, 25, 25, 24, 23, 23, 25, 26, 26, 25, 25], p: [270, 250, 230, 130, 40, 8, 6, 15, 60, 150, 230, 280] },
    rioverde: { n: 'Rio Verde, Goiás, Brasil', lat: -17.8, lon: -50.9, dtr: 11, t: [24, 24, 24, 24, 22, 21, 21, 23, 25, 25, 24, 24], p: [250, 200, 210, 110, 35, 10, 5, 15, 50, 150, 220, 270] },
    ribpreto: { n: 'Ribeirão Preto, São Paulo, Brasil', lat: -21.2, lon: -47.8, dtr: 11, t: [25, 25, 24, 23, 20, 19, 19, 21, 23, 24, 24, 25], p: [280, 220, 180, 70, 60, 25, 15, 20, 65, 135, 190, 290] },
    barreiras: { n: 'Barreiras, Bahia, Brasil', lat: -12.1, lon: -45.0, dtr: 11, t: [26, 26, 26, 25, 24, 23, 23, 24, 26, 27, 26, 26], p: [140, 110, 160, 70, 10, 2, 1, 3, 25, 80, 170, 180] },
    passo: { n: 'Passo Fundo, Rio Grande do Sul, Brasil', lat: -28.3, lon: -52.4, dtr: 9, t: [23, 23, 21, 18, 15, 13, 13, 14, 16, 18, 20, 22], p: [150, 140, 130, 150, 130, 140, 130, 140, 170, 200, 150, 150] },
    petrolina: { n: 'Petrolina, Pernambuco, Brasil', lat: -9.4, lon: -40.5, dtr: 10, t: [27, 27, 27, 26, 25, 24, 24, 25, 27, 28, 28, 28], p: [90, 90, 110, 70, 15, 5, 5, 3, 5, 20, 60, 80] },
    pergamino: { n: 'Pergamino, Buenos Aires, Argentina', lat: -33.9, lon: -60.6, dtr: 11, t: [24, 23, 20, 16, 12, 9, 9, 11, 14, 17, 20, 23], p: [100, 100, 120, 90, 60, 40, 40, 45, 65, 100, 100, 110] },
    iowa: { n: 'Ames, Iowa, Estados Unidos', lat: 42.0, lon: -93.6, dtr: 11, t: [-7, -4, 3, 10, 16, 22, 24, 22, 18, 11, 3, -4], p: [30, 30, 60, 95, 125, 130, 115, 115, 90, 70, 55, 40] },
    punjab: { n: 'Ludhiana, Punjab, Índia', lat: 30.9, lon: 75.9, dtr: 13, t: [14, 17, 22, 28, 33, 34, 31, 30, 29, 25, 19, 15], p: [25, 30, 25, 15, 15, 80, 200, 190, 110, 15, 5, 15] },
    nakuru: { n: 'Nakuru, Quênia', lat: -0.3, lon: 36.1, dtr: 13, t: [17, 18, 18, 18, 17, 16, 15, 16, 16, 17, 17, 17], p: [40, 45, 80, 160, 110, 70, 95, 110, 80, 70, 100, 60] },
    narrabri: { n: 'Narrabri, Nova Gales do Sul, Austrália', lat: -30.3, lon: 149.8, dtr: 14, t: [28, 27, 24, 19, 14, 11, 10, 12, 16, 20, 24, 27], p: [70, 65, 50, 35, 40, 40, 40, 35, 40, 55, 65, 65] }
  };

  // L ciclo (meses) · lo/hi faixa ótima de temperatura média · kc coeficiente médio no ciclo
  // tcrit Tmax crítica (estresse por calor) · frost Tmin mensal média abaixo da qual há dano por geada
  // tol tolerância à seca (0-1) · nb balanço de N (kg/ha/ano) · cov cobertura do solo · inc índice de renda
  var CROPS = [
    { id: 'soja', n: 'Soja', L: 4, lo: 20, hi: 30, kc: 0.85, tcrit: 35, frost: 6, tol: 0.5, fam: 'leg', nb: 30, cov: 0.5, inc: 0.8, note: 'Fixa nitrogênio. Sensível a déficit hídrico na floração e no enchimento de grãos.' },
    { id: 'milho', n: 'Milho', L: 5, lo: 18, hi: 30, kc: 0.95, tcrit: 35, frost: 5, tol: 0.4, fam: 'gra', nb: -60, cov: 0.6, inc: 0.7, note: 'Alta extração de nitrogênio. Muito sensível a falta de água e calor no pendoamento.' },
    { id: 'trigo', n: 'Trigo', L: 5, lo: 10, hi: 22, kc: 0.85, tcrit: 30, frost: -10, tol: 0.45, fam: 'gra', nb: -40, cov: 0.6, inc: 0.6, note: 'Cultura de clima ameno. Calor no espigamento reduz produtividade.' },
    { id: 'sorgo', n: 'Sorgo', L: 4, lo: 22, hi: 35, kc: 0.8, tcrit: 40, frost: 8, tol: 0.8, fam: 'gra', nb: -40, cov: 0.6, inc: 0.45, note: 'Tolerante a seca e calor. Boa opção de segunda safra em regiões secas.' },
    { id: 'feijao', n: 'Feijão', L: 3, lo: 18, hi: 28, kc: 0.8, tcrit: 32, frost: 8, tol: 0.4, fam: 'leg', nb: 20, cov: 0.4, inc: 0.65, note: 'Ciclo curto. Sensível a calor e déficit hídrico na floração.' },
    { id: 'algodao', n: 'Algodão', L: 6, lo: 22, hi: 34, kc: 0.9, tcrit: 38, frost: 10, tol: 0.6, fam: 'mal', nb: -50, cov: 0.3, inc: 0.85, note: 'Ciclo longo, exige calor e água. Deixa pouca cobertura no solo.' },
    { id: 'crotalaria', n: 'Crotalária (adubo verde)', L: 3, lo: 18, hi: 35, kc: 0.7, tcrit: 40, frost: 8, tol: 0.75, fam: 'leg', nb: 80, cov: 1, inc: 0.1, note: 'Adubo verde. Fixa nitrogênio, cobre o solo rápido e quebra ciclo de pragas. Sem renda direta.' },
    { id: 'graobico', n: 'Grão-de-bico', L: 4, lo: 15, hi: 27, kc: 0.75, tcrit: 32, frost: 0, tol: 0.7, fam: 'leg', nb: 25, cov: 0.45, inc: 0.6, note: 'Clima ameno e seco na maturação. Fixa nitrogênio e tolera déficit moderado.' },
    { id: 'girassol', n: 'Girassol', L: 4, lo: 18, hi: 30, kc: 0.85, tcrit: 36, frost: 3, tol: 0.65, fam: 'ast', nb: -30, cov: 0.5, inc: 0.55, note: 'Raiz profunda, tolerância moderada à seca. Diversifica famílias e quebra ciclo de doenças.' }
  ];
  var FAMILIES = { leg: 'leguminosa', gra: 'gramínea', mal: 'malvácea', ast: 'asterácea' };

  var SCENARIOS = [
    { id: 'hoje', n: 'Clima atual', dT: 0, dP: 0, irreg: 0 },
    { id: 'mod', n: 'Aquecimento moderado', dT: 1.5, dP: -5, irreg: 15 },
    { id: 'alto', n: 'Aquecimento alto', dT: 3, dP: -15, irreg: 30 },
    { id: 'seco', n: 'Seca prolongada', dT: 2, dP: -25, irreg: 40 },
    { id: 'conc', n: 'Chuva concentrada', dT: 2, dP: 5, irreg: 45 }
  ];

  var DEFAULTS = {
    region: 'sorriso', awc: 130, irrig: 'none', noTill: false, area: 100,
    dT: 2, dP: -10, irreg: 20, years: 3,
    wW: 6, wS: 7, wI: 5, wR: 6,
    allowed: CROPS.map(function (c) { return c.id; }),
    price: {}, cur: ['soja', 'milho', 'soja']
  };

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function sum(a) { var s = 0; for (var i = 0; i < a.length; i++) s += a[i]; return s; }
  function byId(id) { for (var i = 0; i < CROPS.length; i++) if (CROPS[i].id === id) return CROPS[i]; return null; }

  // Garante tmax/tmin (deriva de dtr quando a fonte só traz a média).
  function prep(reg) {
    var d = reg.dtr == null ? 10 : reg.dtr;
    return {
      n: reg.n, lat: reg.lat, lon: reg.lon, source: reg.source,
      t: reg.t.slice(), p: reg.p.slice(),
      tmax: reg.tmax ? reg.tmax.slice() : reg.t.map(function (v) { return v + d / 2; }),
      tmin: reg.tmin ? reg.tmin.slice() : reg.t.map(function (v) { return v - d / 2; })
    };
  }

  // Radiação extraterrestre (FAO-56), em mm/dia equivalentes de evaporação.
  function ra(latDeg, doy) {
    var phi = latDeg * Math.PI / 180;
    var dr = 1 + 0.033 * Math.cos(2 * Math.PI * doy / 365);
    var dec = 0.409 * Math.sin(2 * Math.PI * doy / 365 - 1.39);
    var x = clamp(-Math.tan(phi) * Math.tan(dec), -1, 1);
    var ws = Math.acos(x);
    var r = (24 * 60 / Math.PI) * 0.0820 * dr * (ws * Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.sin(ws));
    return r * 0.408;
  }
  // ETo mensal (mm) por Hargreaves-Samani, com o aquecimento dT somado a Tmax e Tmin.
  function etoMonthly(reg, dT) {
    var lat = reg.lat == null ? 0 : reg.lat, out = [];
    for (var m = 0; m < 12; m++) {
      var tmax = reg.tmax[m] + dT, tmin = reg.tmin[m] + dT, tm = (tmax + tmin) / 2;
      var daily = 0.0023 * (tm + 17.8) * Math.sqrt(Math.max(tmax - tmin, 1)) * ra(lat, MID_DOY[m]);
      out.push(Math.max(0, daily) * MDAYS[m]);
    }
    return out;
  }

  // Aptidão de uma cultura para cada mês de plantio.
  function suit(c, reg, o, dT, dP) {
    if (dT == null) dT = o.dT; if (dP == null) dP = o.dP;
    var eto = etoMonthly(reg, dT);
    var effFrac = 0.75 * (1 - 0.5 * o.irreg / 100);
    var buf = 0.35 * o.awc * (o.noTill ? 1.1 : 1);
    var by = [], det = [];
    for (var s = 0; s < 12; s++) {
      var tf = 0, pr = 0, et = 0, heat = 0, hm = 0, fr = 0, frostN = 0, heatN = 0;
      for (var k = 0; k < c.L; k++) {
        var m = (s + k) % 12, t = reg.t[m] + dT, tx = reg.tmax[m] + dT, tn = reg.tmin[m] + dT, d = 0;
        if (t < c.lo) d = (c.lo - t) / 9; else if (t > c.hi) d = (t - c.hi) / 7;
        tf += Math.max(0, 1 - d);
        if (tx > c.tcrit) { heat += clamp((tx - c.tcrit) / 6, 0, 1); heatN++; }
        if (tn < c.frost) frostN++;
        pr += reg.p[m] * (1 + dP / 100); et += eto[m];
      }
      tf /= c.L;
      var heatF = 1 - 0.6 * heat / c.L;
      var frostF = Math.max(0.1, 1 - 0.3 * frostN);
      var need = c.kc * et, rainEff = effFrac * pr;
      var r = (rainEff + buf) / Math.max(need, 1);
      if (o.irrig === 'full') r = Math.max(r, 1);
      else if (o.irrig === 'partial' && r < 1) r = r + (1 - r) * 0.5;
      var w = r >= 1 ? 1 : Math.pow(r, 1.2 - 0.8 * c.tol);
      by.push(tf * heatF * frostF * w);
      det.push({ ratio: Math.min(r, 1.5), tf: tf, heatF: heatF, frostF: frostF, wf: w, need: need, rainEff: rainEff, rain: pr, deficit: Math.max(0, need - rainEff - buf), heatN: heatN, frostN: frostN });
    }
    // desempate: entre meses de aptidão quase igual, prefere o de maior folga de água
    var bi = 0; for (var i = 1; i < 12; i++) if (by[i] + 0.01 * det[i].ratio > by[bi] + 0.01 * det[bi].ratio) bi = i;
    var d0 = det[bi];
    return { c: c, by: by, best: by[bi], start: bi, wf: d0.wf, need: d0.need, rainEff: d0.rainEff, rain: d0.rain, deficit: d0.deficit, heatN: d0.heatN, frostN: d0.frostN, tf: d0.tf, heatF: d0.heatF, frostF: d0.frostF };
  }
  function suitAll(reg, o, dT, dP) {
    var S = {}; for (var i = 0; i < CROPS.length; i++) S[CROPS[i].id] = suit(CROPS[i], reg, o, dT, dP); return S;
  }

  function scoreRot(ids, S, o) {
    var n = ids.length, cs = ids.map(function (i) { return S[i]; });
    var adapt = sum(cs.map(function (x) { return x.best; })) / n;
    var wfm = sum(cs.map(function (x) { return x.wf; })) / n;
    var needm = sum(cs.map(function (x) { return x.need; })) / n;
    var water = clamp(0.6 * (1 - needm / 900) + 0.4 * wfm, 0, 1);
    var leg = cs.some(function (x) { return x.c.fam === 'leg'; }) ? 1 : 0;
    var cov = sum(cs.map(function (x) { return x.c.cov; })) / n;
    var fams = {}; cs.forEach(function (x) { fams[x.c.fam] = 1; });
    var nf = Object.keys(fams).length;
    var pen = 0, pairs = n === 2 ? 1 : n;
    for (var i = 0; i < pairs; i++) if (cs[i].c.fam === cs[(i + 1) % n].c.fam) pen += 0.18;
    var soil = clamp(0.15 + 0.3 * leg + 0.3 * cov + 0.25 * (nf / Math.min(n, 3)) - pen + (o.noTill ? 0.08 : 0), 0, 1);
    var inc = clamp(sum(cs.map(function (x) { return x.c.inc * (o.price[x.c.id] == null ? 1 : o.price[x.c.id]) * x.best; })) / n, 0, 1);
    var res = Math.min.apply(null, cs.map(function (x) { return x.best; }));
    var W = o.wW + o.wS + o.wI + o.wR;
    var tot = (2 * adapt + o.wW * water + o.wS * soil + o.wI * inc + o.wR * res) / (2 + W);
    return { ids: ids, cs: cs, total: tot, adapt: adapt, water: water, soil: soil, inc: inc, res: res, nb: sum(cs.map(function (x) { return x.c.nb; })) / n, needm: needm };
  }

  // Busca todas as sequências sem repetir cultura e devolve as melhores com conjuntos distintos.
  function plansFor(S, o, count) {
    var ids = o.allowed.filter(function (id) { return !!S[id]; }), n = Math.min(o.years, ids.length), all = [];
    if (n < 2) return [];
    (function rec(seq, used) {
      if (seq.length === n) { all.push(scoreRot(seq.slice(), S, o)); return; }
      for (var i = 0; i < ids.length; i++) { if (used[i]) continue; used[i] = true; seq.push(ids[i]); rec(seq, used); seq.pop(); used[i] = false; }
    })([], []);
    all.sort(function (a, b) { return b.total - a.total; });
    var out = [], seen = {};
    for (var j = 0; j < all.length && out.length < (count || 3); j++) {
      var key = all[j].ids.slice().sort().join();
      if (seen[key]) continue; seen[key] = 1; out.push(all[j]);
    }
    return out;
  }

  // Reavalia listas de rotações em uma grade de cenários.
  function stress(lists, reg, o) {
    var dTs = [0, 1, 2, 3, 4], dPs = [-30, -20, -10, 0, 10];
    var M = lists.map(function () { return dPs.map(function () { return []; }); });
    var mn = lists.map(function () { return 1; });
    dPs.forEach(function (dp, ri) {
      dTs.forEach(function (dt) {
        var S = suitAll(reg, o, dt, dp);
        lists.forEach(function (ids, q) { var v = scoreRot(ids, S, o).total; M[q][ri].push(v); if (v < mn[q]) mn[q] = v; });
      });
    });
    return { dTs: dTs, dPs: dPs, M: M, min: mn };
  }

  function monthlyClimate(reg, o) {
    var eto = etoMonthly(reg, o.dT), eto0 = etoMonthly(reg, 0), effFrac = 0.75 * (1 - 0.5 * o.irreg / 100), rows = [];
    for (var m = 0; m < 12; m++) {
      var p1 = reg.p[m] * (1 + o.dP / 100);
      rows.push({ m: m, t0: reg.t[m], t1: reg.t[m] + o.dT, tmax1: reg.tmax[m] + o.dT, tmin1: reg.tmin[m] + o.dT, p0: reg.p[m], p1: p1, eto0: eto0[m], eto1: eto[m], bal1: effFrac * p1 - eto[m], bal0: 0.75 * reg.p[m] - eto0[m] });
    }
    return rows;
  }

  // ---------- histórico, tendência e projeção ----------
  function mean(a) { return a.length ? sum(a) / a.length : 0; }
  function baseDtr(base) { var d = []; for (var m = 0; m < 12; m++) d.push((base.tmax ? base.tmax[m] : base.t[m] + 5) - (base.tmin ? base.tmin[m] : base.t[m] - 5)); return mean(d); }

  // Regressão linear simples. t é a razão inclinação/erro-padrão (|t| > 2 indica tendência distinguível do ruído).
  function linfit(xs, ys) {
    var n = xs.length;
    if (n < 4) return { slope: 0, intercept: mean(ys), r2: 0, sd: 0, t: 0, n: n };
    var mx = mean(xs), my = mean(ys), sxx = 0, sxy = 0, syy = 0, i;
    for (i = 0; i < n; i++) { var dx = xs[i] - mx, dy = ys[i] - my; sxx += dx * dx; sxy += dx * dy; syy += dy * dy; }
    var slope = sxx ? sxy / sxx : 0, icpt = my - slope * mx, sse = 0;
    for (i = 0; i < n; i++) { var r = ys[i] - (icpt + slope * xs[i]); sse += r * r; }
    var sd = Math.sqrt(sse / (n - 2)), se = sxx ? sd / Math.sqrt(sxx) : 0;
    return { slope: slope, intercept: icpt, r2: syy ? 1 - sse / syy : 0, sd: sd, t: se ? slope / se : 0, n: n };
  }
  // Clima de um ano (objeto {year,t,p,tmax,tmin}) no formato do simulador.
  function yearReg(y, base) {
    return prep({ n: base.n, lat: base.lat, lon: base.lon, source: '', t: y.t, p: y.p, tmax: y.tmax || null, tmin: y.tmin || null, dtr: baseDtr(base) });
  }
  // Média mensal de um período de anos.
  function periodReg(years, y0, y1, base) {
    var ys = years.filter(function (y) { return y.year >= y0 && y.year <= y1; });
    if (!ys.length) return null;
    var dtr = baseDtr(base), out = { n: base.n, lat: base.lat, lon: base.lon, source: '', t: [], p: [], tmax: [], tmin: [], count: ys.length };
    for (var m = 0; m < 12; m++) {
      out.t.push(mean(ys.map(function (y) { return y.t[m]; })));
      out.p.push(mean(ys.map(function (y) { return y.p[m]; })));
      out.tmax.push(mean(ys.map(function (y) { return y.tmax ? y.tmax[m] : y.t[m] + dtr / 2; })));
      out.tmin.push(mean(ys.map(function (y) { return y.tmin ? y.tmin[m] : y.t[m] - dtr / 2; })));
    }
    return out;
  }
  function annualStats(reg) {
    var eto = etoMonthly(reg, 0), P = sum(reg.p), E = sum(eto), def = 0, m;
    for (m = 0; m < 12; m++) if (0.75 * reg.p[m] - eto[m] < 0) def++;
    return { meanT: mean(reg.t), totalP: P, eto: E, balance: 0.75 * P - E, dryMonths: reg.p.filter(function (v) { return v < 50; }).length, deficitMonths: def, hotMonths: reg.tmax.filter(function (v) { return v >= 33; }).length };
  }
  // Nota de cada ano para listas de rotações. A irregularidade da chuva já vem nos dados observados.
  function yearScores(years, base, o, lists) {
    var oo = {}; for (var k in o) oo[k] = o[k]; oo.irreg = 0;
    return years.map(function (y) {
      var reg = yearReg(y, base), S = suitAll(reg, oo, 0, 0);
      return { year: y.year, S: S, rots: lists.map(function (ids) { return scoreRot(ids, S, oo); }), stats: annualStats(reg) };
    });
  }
  function trends(years) {
    var xs = years.map(function (y) { return y.year; }), T = years.map(function (y) { return mean(y.t); }), P = years.map(function (y) { return sum(y.p); });
    return { xs: xs, T: T, P: P, t: linfit(xs, T), p: linfit(xs, P) };
  }
  function applyDelta(reg, dT, dPfrac) {
    var f = Math.max(0.2, 1 + dPfrac);
    return { n: reg.n, lat: reg.lat, lon: reg.lon, source: '', t: reg.t.map(function (v) { return v + dT; }), tmax: reg.tmax.map(function (v) { return v + dT; }), tmin: reg.tmin.map(function (v) { return v + dT; }), p: reg.p.map(function (v) { return v * f; }) };
  }
  // Extrapola a tendência linear observada a partir da média dos últimos 10 anos.
  // Os casos "quente e seco" e "ameno e úmido" somam e subtraem 1 desvio-padrão de variação entre anos.
  function project(years, target) {
    var tr = trends(years), last = years[years.length - 1].year, y0 = Math.max(years[0].year, last - 9), yc = (y0 + last) / 2, dy = target - yc;
    var meanP = mean(tr.P), dT = tr.t.slope * dy, dP = meanP ? tr.p.slope * dy / meanP : 0, sdT = tr.t.sd, sdP = meanP ? tr.p.sd / meanP : 0;
    return { tr: tr, y0: y0, last: last, target: target, dT: dT, dP: dP, sdT: sdT, sdP: sdP, meanP: meanP,
      cases: [{ id: 'central', n: 'Tendência', dT: dT, dP: dP }, { id: 'quente', n: 'Ano quente e seco', dT: dT + sdT, dP: dP - sdP }, { id: 'ameno', n: 'Ano ameno e úmido', dT: dT - sdT, dP: dP + sdP }] };
  }
  // Série SIMULADA para demonstração quando a NASA não responde. Nunca representa medições.
  function demoSeries(base, y0, y1, seed) {
    var s = (seed >>> 0) || 7, rand = function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
    var gauss = function () { return Math.sqrt(-2 * Math.log(rand() + 1e-9)) * Math.cos(2 * Math.PI * rand()); };
    var out = [], ar = 0;
    for (var y = y0; y <= y1; y++) {
      ar = 0.5 * ar + 0.5 * gauss(); var warm = 0.03 * (y - 2005) + ar * 0.5, wet = Math.exp(-0.0015 * (y - 2005) + 0.18 * gauss());
      out.push({ year: y, t: base.t.map(function (v) { return +(v + warm).toFixed(2); }), p: base.p.map(function (v) { return Math.round(v * wet * Math.exp(0.3 * gauss())); }), tmax: null, tmin: null });
    }
    return out;
  }
  // Leitura da previsão do tempo (30 dias passados + 16 futuros) contra a normal climática da gleba.
  function assessWeather(days, today, reg) {
    var r = { rainPast: 0, etoPast: 0, rainFut: 0, etoFut: 0, normPast: 0, normFut: 0, hotDays: 0, coldNights: 0, frostNights: 0, dryRun: 0, tmaxFut: -99, tminFut: 99, nPast: 0, nFut: 0 }, run = 0;
    days.forEach(function (d) {
      var m = parseInt(d.date.slice(5, 7), 10) - 1, norm = reg.p[m] / MDAYS[m], past = d.date < today;
      if (past) { r.nPast++; r.rainPast += d.rain || 0; r.etoPast += d.et0 || 0; r.normPast += norm; }
      else {
        r.nFut++; r.rainFut += d.rain || 0; r.etoFut += d.et0 || 0; r.normFut += norm;
        if (d.tmax != null) { r.tmaxFut = Math.max(r.tmaxFut, d.tmax); if (d.tmax >= 35) r.hotDays++; }
        if (d.tmin != null) { r.tminFut = Math.min(r.tminFut, d.tmin); if (d.tmin <= 3) r.coldNights++; if (d.tmin <= 0) r.frostNights++; }
        if ((d.rain || 0) < 1) { run++; r.dryRun = Math.max(r.dryRun, run); } else run = 0;
      }
    });
    r.ratioPast = r.normPast > 1 ? r.rainPast / r.normPast : null; r.ratioFut = r.normFut > 1 ? r.rainFut / r.normFut : null;
    return r;
  }
  // Situação do mês atual para cada cultura: está perto do melhor mês de plantio e a previsão ajuda?
  function plantingAdvice(S, allowed, month, a) {
    return allowed.filter(function (id) { return S[id]; }).map(function (id) {
      var s = S[id], here = s.by[month], rel = s.best > 0 ? here / s.best : 0, why = [], ok = true;
      if (a.ratioFut != null && a.ratioFut < 0.6) { ok = false; why.push('chuva prevista em ' + Math.round(a.ratioFut * 100) + '% da normal'); }
      if (a.dryRun >= 8) { ok = false; why.push(a.dryRun + ' dias secos seguidos na previsão'); }
      if (a.frostNights > 0 && s.c.frost > 0) { ok = false; why.push('geada prevista'); }
      if (a.hotDays >= 3 && a.tmaxFut >= s.c.tcrit) { ok = false; why.push('calor acima de ' + s.c.tcrit + ' °C'); }
      return { id: id, here: here, rel: rel, window: rel >= 0.85 && here > 0.25, ok: ok, why: why };
    });
  }

  return { mean: mean, linfit: linfit, yearReg: yearReg, periodReg: periodReg, annualStats: annualStats, yearScores: yearScores, trends: trends, applyDelta: applyDelta, project: project, demoSeries: demoSeries, assessWeather: assessWeather, plantingAdvice: plantingAdvice, MONTHS: MONTHS, MDAYS: MDAYS, REGIONS: REGIONS, CROPS: CROPS, FAMILIES: FAMILIES, SCENARIOS: SCENARIOS, DEFAULTS: DEFAULTS, byId: byId, prep: prep, etoMonthly: etoMonthly, suit: suit, suitAll: suitAll, scoreRot: scoreRot, plansFor: plansFor, stress: stress, monthlyClimate: monthlyClimate, clamp: clamp, sum: sum };
});
