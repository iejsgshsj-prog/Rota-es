(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var token = new URLSearchParams(location.search).get('token');
  function msg(t, k) { var m = $('msg'); m.hidden = !t; m.textContent = t || ''; m.className = 'msg' + (k ? ' ' + k : ''); }
  if (!token) { $('f').hidden = true; msg('Link incompleto. Peça um novo em "Esqueci a senha".', 'err'); return; }
  $('f').onsubmit = function (e) {
    e.preventDefault();
    if ($('p1').value !== $('p2').value) return msg('As senhas não são iguais.', 'err');
    $('go').disabled = true;
    Api('POST', '/api/reset', { token: token, password: $('p1').value }).then(function () {
      $('f').hidden = true; msg('Senha alterada. Entre com a nova senha.', 'ok');
      var a = document.createElement('a'); a.className = 'btn go'; a.href = '/entrar.html'; a.textContent = 'Ir para o login'; a.style.marginTop = '14px'; $('msg').after(a);
    }).catch(function (er) { msg(er.message, 'err'); $('go').disabled = false; });
  };
})();
