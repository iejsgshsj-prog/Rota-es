(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var token = new URLSearchParams(location.search).get('token');
  if (!token) { $('ttl').textContent = 'Link incompleto'; $('txt').textContent = 'Abra o link exatamente como veio no e-mail.'; return; }
  Api('POST', '/api/verify', { token: token }).then(function () {
    $('ttl').textContent = 'E-mail confirmado';
    $('txt').textContent = 'Sua conta está ativa. Agora você pode salvar cenários.';
    $('go').hidden = false; window.refreshUser();
  }).catch(function (e) {
    $('ttl').textContent = 'Não foi possível confirmar';
    $('txt').textContent = e.message;
    $('go').hidden = false; $('go').textContent = 'Entrar para pedir novo link'; $('go').href = '/entrar.html';
  });
})();
