'use strict';
/**
 * Campo em Rotação — servidor próprio, sem dependências externas (Node >= 20).
 * Contas com confirmação de e-mail, recuperação de senha, cenários salvos
 * e proxy para a API NASA POWER.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const tls = require('node:tls');

// ---------- configuração ----------
(function loadEnv() {
  const f = path.join(__dirname, '.env');
  if (!fs.existsSync(f)) return;
  for (const line of fs.readFileSync(f, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
})();
const env = process.env;
const PORT = parseInt(env.PORT || '3000', 10);
const BASE_URL = (env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const DATA_DIR = path.resolve(env.DATA_DIR || path.join(__dirname, 'data'));
const MAIL_MODE = (env.MAIL_MODE || 'console').toLowerCase();
const MAIL_FROM = env.MAIL_FROM || 'Campo em Rotação <nao-responda@localhost>';
const SECURE_COOKIE = env.COOKIE_SECURE === '1' || BASE_URL.startsWith('https://');
const PUBLIC_DIR = path.join(__dirname, 'public');
const POWER_BASE = (env.POWER_BASE || 'https://power.larc.nasa.gov').replace(/\/$/, '');
const METEO_BASE = (env.METEO_BASE || 'https://api.open-meteo.com').replace(/\/$/, '');
const SESSION_TTL = 30 * 24 * 3600 * 1000;
const VERIFY_TTL = 24 * 3600 * 1000;
const RESET_TTL = 3600 * 1000;
const MAX_PLANS = 30;
fs.mkdirSync(DATA_DIR, { recursive: true });

// ---------- armazenamento (arquivo JSON, escrita atômica) ----------
const DB_FILE = path.join(DATA_DIR, 'db.json');
let db = { users: [], sessions: {}, tokens: [], plans: [] };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8'))); } catch (_) { /* primeiro uso */ }
let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    const tmp = DB_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 });
    fs.renameSync(tmp, DB_FILE);
  }, 50);
}
function flushSync() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
}
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const rnd = (n = 32) => crypto.randomBytes(n).toString('base64url');

// ---------- senhas ----------
function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(pw, salt, 64);
  return salt.toString('hex') + ':' + key.toString('hex');
}
function checkPassword(pw, stored) {
  const [s, k] = String(stored).split(':');
  const key = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64);
  const want = Buffer.from(k, 'hex');
  return want.length === key.length && crypto.timingSafeEqual(key, want);
}
const DUMMY_HASH = hashPassword('dummy-password-for-timing');

// ---------- limite de requisições ----------
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const h = hits.get(key);
  if (!h || h.reset < now) { hits.set(key, { n: 1, reset: now + windowMs }); return false; }
  h.n++;
  return h.n > max;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (v.reset < now) hits.delete(k); }, 600000).unref();

// ---------- e-mail ----------
function smtpSend({ to, subject, text, html }) {
  return new Promise((resolve, reject) => {
    const host = env.SMTP_HOST, port = parseInt(env.SMTP_PORT || '465', 10);
    const plain = env.SMTP_PLAIN_TEST === '1'; // só para testes locais
    const sock = plain ? net.connect(port, host) : tls.connect({ host, port, servername: host });
    const fromAddr = (MAIL_FROM.match(/<([^>]+)>/) || [null, MAIL_FROM])[1];
    const boundary = 'b' + rnd(9);
    const msg = [
      `From: ${MAIL_FROM}`, `To: ${to}`,
      `Subject: =?UTF-8?B?${Buffer.from(subject).toString('base64')}?=`,
      'MIME-Version: 1.0', `Date: ${new Date().toUTCString()}`,
      `Message-ID: <${rnd(12)}@${(fromAddr.split('@')[1] || 'localhost')}>`,
      `Content-Type: multipart/alternative; boundary="${boundary}"`, '',
      `--${boundary}`, 'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '',
      Buffer.from(text).toString('base64').replace(/(.{76})/g, '$1\r\n'), '',
      `--${boundary}`, 'Content-Type: text/html; charset=UTF-8', 'Content-Transfer-Encoding: base64', '',
      Buffer.from(html).toString('base64').replace(/(.{76})/g, '$1\r\n'), '',
      `--${boundary}--`, ''
    ].join('\r\n');
    const steps = [{ expect: 220 }, { send: 'EHLO campo-em-rotacao', expect: 250 }];
    if (env.SMTP_USER) {
      steps.push({ send: 'AUTH LOGIN', expect: 334 });
      steps.push({ send: Buffer.from(env.SMTP_USER).toString('base64'), expect: 334 });
      steps.push({ send: Buffer.from(env.SMTP_PASS || '').toString('base64'), expect: 235 });
    }
    steps.push({ send: `MAIL FROM:<${fromAddr}>`, expect: 250 });
    steps.push({ send: `RCPT TO:<${to}>`, expect: [250, 251] });
    steps.push({ send: 'DATA', expect: 354 });
    steps.push({ send: msg.replace(/\r?\n\./g, '\r\n..') + '\r\n.', expect: 250 });
    steps.push({ send: 'QUIT', expect: 221 });
    let i = 0, buf = '';
    const timer = setTimeout(() => { sock.destroy(); reject(new Error('SMTP timeout')); }, 20000);
    const fail = (e) => { clearTimeout(timer); sock.destroy(); reject(e); };
    sock.on('error', fail);
    sock.on('data', (d) => {
      buf += d.toString('utf8');
      const lines = buf.split('\r\n'); buf = lines.pop();
      for (const line of lines) {
        const m = line.match(/^(\d{3})([ -])/);
        if (!m || m[2] === '-') continue;
        const code = parseInt(m[1], 10);
        const want = [].concat(steps[i].expect);
        if (!want.includes(code)) return fail(new Error('SMTP: ' + line));
        i++;
        if (i >= steps.length) { clearTimeout(timer); sock.end(); return resolve(); }
        sock.write(steps[i].send + '\r\n');
      }
    });
  });
}
async function sendMail({ to, subject, text, html }) {
  try {
    if (MAIL_MODE === 'resend') {
      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST', headers: { Authorization: 'Bearer ' + env.RESEND_API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from: MAIL_FROM, to: [to], subject, text, html })
      });
      if (!r.ok) throw new Error('Resend ' + r.status + ' ' + (await r.text()).slice(0, 200));
    } else if (MAIL_MODE === 'brevo') {
      const m = MAIL_FROM.match(/^(.*)<([^>]+)>$/);
      const r = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST', headers: { 'api-key': env.BREVO_API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ sender: { name: m ? m[1].trim().replace(/"/g, '') : 'Campo em Rotação', email: m ? m[2] : MAIL_FROM }, to: [{ email: to }], subject, textContent: text, htmlContent: html })
      });
      if (!r.ok) throw new Error('Brevo ' + r.status + ' ' + (await r.text()).slice(0, 200));
    } else if (MAIL_MODE === 'smtp') {
      await smtpSend({ to, subject, text, html });
    } else {
      const entry = `[${new Date().toISOString()}] Para: ${to}\nAssunto: ${subject}\n${text}\n\n`;
      fs.appendFileSync(path.join(DATA_DIR, 'outbox.log'), entry);
      console.log('\n--- E-MAIL (modo console) ---\n' + entry + '-----------------------------\n');
    }
    return true;
  } catch (e) {
    console.error('Falha ao enviar e-mail:', e.message);
    return false;
  }
}
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function mailLayout(title, intro, linkUrl, cta, outro) {
  const text = `${title}\n\n${intro}\n\n${linkUrl}\n\n${outro}\n\nCampo em Rotação — projeto independente. Não é um produto oficial da NASA.`;
  const html = `<div style="font-family:Segoe UI,Arial,sans-serif;max-width:520px;margin:auto;padding:24px;color:#13211d">
<h2 style="margin:0 0 12px">${esc(title)}</h2><p style="line-height:1.5">${esc(intro)}</p>
<p style="margin:24px 0"><a href="${esc(linkUrl)}" style="background:#2c7a4b;color:#fff;padding:12px 20px;border-radius:4px;text-decoration:none;font-weight:600">${esc(cta)}</a></p>
<p style="font-size:13px;color:#586a64;line-height:1.5">Se o botão não abrir, copie este endereço no navegador:<br>${esc(linkUrl)}</p>
<p style="font-size:13px;color:#586a64">${esc(outro)}</p>
<hr style="border:0;border-top:1px solid #c9d4ce;margin:20px 0"><p style="font-size:12px;color:#586a64">Campo em Rotação — projeto independente. Não é um produto oficial da NASA.</p></div>`;
  return { text, html };
}
function makeToken(uid, type, ttl) {
  db.tokens = db.tokens.filter((t) => !(t.uid === uid && t.type === type) && t.exp > Date.now());
  const raw = rnd(32);
  db.tokens.push({ uid, type, hash: sha(raw), exp: Date.now() + ttl });
  save();
  return raw;
}
function useToken(raw, type) {
  const h = sha(String(raw || ''));
  const i = db.tokens.findIndex((t) => t.type === type && t.hash === h && t.exp > Date.now());
  if (i < 0) return null;
  const t = db.tokens[i];
  db.tokens.splice(i, 1);
  save();
  return t.uid;
}
async function sendVerification(user) {
  const tok = makeToken(user.id, 'verify', VERIFY_TTL);
  const url = `${BASE_URL}/verificar.html?token=${tok}`;
  const m = mailLayout('Confirme seu e-mail', `Olá, ${user.name}. Falta um passo para ativar sua conta no Campo em Rotação. O link vale por 24 horas.`, url, 'Confirmar e-mail', 'Se você não criou esta conta, ignore esta mensagem.');
  return sendMail({ to: user.email, subject: 'Confirme seu e-mail — Campo em Rotação', ...m });
}

// ---------- utilidades HTTP ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8' };
const SEC_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'",
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()'
};
if (SECURE_COOKIE) SEC_HEADERS['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
function send(res, status, body, headers = {}) {
  res.writeHead(status, Object.assign({}, SEC_HEADERS, headers));
  res.end(body);
}
function json(res, status, obj, headers = {}) {
  send(res, status, JSON.stringify(obj), Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 100000) { reject(Object.assign(new Error('grande'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch (_) { reject(Object.assign(new Error('JSON inválido'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
function parseCookies(req) {
  const out = {};
  for (const p of String(req.headers.cookie || '').split(';')) { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = p.slice(i + 1).trim(); }
  return out;
}
function currentUser(req) {
  const sid = parseCookies(req).sid;
  if (!sid) return null;
  const s = db.sessions[sha(sid)];
  if (!s || s.exp < Date.now()) return null;
  return db.users.find((u) => u.id === s.uid) || null;
}
function cookieHeader(value, maxAgeSec) {
  return `sid=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAgeSec}${SECURE_COOKIE ? '; Secure' : ''}`;
}
function startSession(res, user) {
  const sid = rnd(32);
  db.sessions[sha(sid)] = { uid: user.id, exp: Date.now() + SESSION_TTL };
  save();
  return cookieHeader(sid, SESSION_TTL / 1000);
}
const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, verified: !!u.verified });
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/;
const clientIp = (req) => (req.headers['x-forwarded-for'] && env.TRUST_PROXY === '1' ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress) || 'x';
function pwProblem(pw) {
  if (typeof pw !== 'string' || pw.length < 8) return 'A senha precisa ter pelo menos 8 caracteres.';
  if (pw.length > 200) return 'Senha longa demais.';
  if (!/[a-zA-Z]/.test(pw) || !/[0-9]/.test(pw)) return 'Use letras e números na senha.';
  return null;
}

// ---------- NASA POWER ----------
const powerCache = new Map();
const MDAYS = [31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
const MKEYS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
async function fetchPower(lat, lon) {
  const key = lat.toFixed(2) + ',' + lon.toFixed(2);
  const hit = powerCache.get(key);
  if (hit && hit.exp > Date.now()) return hit.data;
  const url = POWER_BASE + '/api/temporal/climatology/point?parameters=T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,ALLSKY_SFC_SW_DWN,RH2M&community=AG' +
    `&longitude=${lon.toFixed(4)}&latitude=${lat.toFixed(4)}&format=JSON`;
  const ctl = new AbortController();
  const to = setTimeout(() => ctl.abort(), 25000);
  let r;
  try { r = await fetch(url, { signal: ctl.signal, headers: { Accept: 'application/json' } }); } finally { clearTimeout(to); }
  if (!r.ok) throw new Error('NASA POWER respondeu ' + r.status);
  const j = await r.json();
  const P = j && j.properties && j.properties.parameter;
  if (!P || !P.T2M || !P.PRECTOTCORR) throw new Error('Resposta inesperada da NASA POWER');
  const arr = (name) => MKEYS.map((k) => { const v = P[name] && P[name][k]; return (typeof v === 'number' && v > -900) ? v : null; });
  const t = arr('T2M'), tmax = arr('T2M_MAX'), tmin = arr('T2M_MIN'), pd = arr('PRECTOTCORR'), rad = arr('ALLSKY_SFC_SW_DWN'), rh = arr('RH2M');
  if (t.includes(null) || pd.includes(null)) throw new Error('Dados incompletos para esta coordenada');
  const data = {
    lat, lon, source: 'NASA POWER (climatologia mensal, comunidade AG)', fetchedAt: new Date().toISOString(),
    t: t.map((v) => +v.toFixed(1)),
    tmax: tmax.includes(null) ? null : tmax.map((v) => +v.toFixed(1)),
    tmin: tmin.includes(null) ? null : tmin.map((v) => +v.toFixed(1)),
    p: pd.map((v, i) => Math.round(v * MDAYS[i])),
    rad: rad.includes(null) ? null : rad.map((v) => +v.toFixed(2)),
    rh: rh.includes(null) ? null : rh.map((v) => Math.round(v))
  };
  powerCache.set(key, { data, exp: Date.now() + 30 * 24 * 3600 * 1000 });
  return data;
}


async function getJson(url, ms) {
  const ctl = new AbortController();
  const to = setTimeout(() => ctl.abort(), ms || 25000);
  try {
    const r = await fetch(url, { signal: ctl.signal, headers: { Accept: 'application/json' } });
    if (!r.ok) throw new Error('o serviço respondeu ' + r.status);
    return await r.json();
  } finally { clearTimeout(to); }
}
const okNum = (v) => typeof v === 'number' && isFinite(v) && v > -900;

// Série mensal ano a ano (NASA POWER, comunidade AG) para comparar períodos e estimar tendência.
const histCache = new Map();
async function fetchHistory(lat, lon) {
  const key = lat.toFixed(2) + ',' + lon.toFixed(2);
  const hit = histCache.get(key);
  if (hit && hit.exp > Date.now()) return hit.data;
  const start = 1991, end = new Date().getUTCFullYear() - 1;
  const j = await getJson(POWER_BASE + '/api/temporal/monthly/point?parameters=T2M,T2M_MAX,T2M_MIN,PRECTOTCORR&community=AG' +
    `&longitude=${lon.toFixed(4)}&latitude=${lat.toFixed(4)}&start=${start}&end=${end}&format=JSON`, 40000);
  const P = j && j.properties && j.properties.parameter;
  if (!P || !P.T2M || !P.PRECTOTCORR) throw new Error('resposta inesperada da NASA POWER');
  const years = [];
  for (let y = start; y <= end; y++) {
    const t = [], tx = [], tn = [], p = [];
    let complete = true;
    for (let m = 1; m <= 12; m++) {
      const k = y + String(m).padStart(2, '0');
      const vt = P.T2M[k], vp = P.PRECTOTCORR[k];
      if (!okNum(vt) || !okNum(vp)) { complete = false; break; }
      t.push(+vt.toFixed(2)); p.push(Math.round(vp * new Date(Date.UTC(y, m, 0)).getUTCDate()));
      tx.push(P.T2M_MAX ? P.T2M_MAX[k] : null); tn.push(P.T2M_MIN ? P.T2M_MIN[k] : null);
    }
    if (!complete) continue;
    const hasRange = tx.every(okNum) && tn.every(okNum);
    years.push({ year: y, t, p, tmax: hasRange ? tx.map((v) => +v.toFixed(2)) : null, tmin: hasRange ? tn.map((v) => +v.toFixed(2)) : null });
  }
  if (years.length < 10) throw new Error('série histórica incompleta para esta coordenada');
  const data = { lat, lon, source: 'NASA POWER · médias mensais ' + years[0].year + '–' + years[years.length - 1].year + ' (comunidade AG)', fetchedAt: new Date().toISOString(), years };
  histCache.set(key, { data, exp: Date.now() + 7 * 24 * 3600 * 1000 });
  return data;
}

// Tempo dos últimos 30 dias e dos próximos 16 dias (Open-Meteo, modelos meteorológicos globais; não é dado NASA).
const wxCache = new Map();
async function fetchWeather(lat, lon) {
  const key = lat.toFixed(2) + ',' + lon.toFixed(2);
  const hit = wxCache.get(key);
  if (hit && hit.exp > Date.now()) return hit.data;
  const j = await getJson(METEO_BASE + '/v1/forecast?latitude=' + lat.toFixed(4) + '&longitude=' + lon.toFixed(4) +
    '&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,et0_fao_evapotranspiration&past_days=30&forecast_days=16&timezone=auto', 20000);
  const d = j && j.daily;
  if (!d || !Array.isArray(d.time) || !d.time.length) throw new Error('resposta inesperada do serviço de previsão');
  const num = (a, i) => (a && okNum(a[i]) ? +a[i].toFixed(1) : null);
  const days = d.time.map((date, i) => ({ date, tmax: num(d.temperature_2m_max, i), tmin: num(d.temperature_2m_min, i), rain: num(d.precipitation_sum, i) || 0, et0: num(d.et0_fao_evapotranspiration, i) || 0 }));
  const today = new Date(Date.now() + (j.utc_offset_seconds || 0) * 1000).toISOString().slice(0, 10);
  const data = { lat, lon, source: 'Open-Meteo (modelos meteorológicos globais)', fetchedAt: new Date().toISOString(), today, days };
  wxCache.set(key, { data, exp: Date.now() + 3600 * 1000 });
  return data;
}
function coords(url) {
  const lat = parseFloat(url.searchParams.get('lat')), lon = parseFloat(url.searchParams.get('lon'));
  return (lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) ? { lat, lon } : null;
}

// ---------- rotas da API ----------
async function api(req, res, url) {
  const route = req.method + ' ' + url.pathname;
  const ip = clientIp(req);
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    const origin = req.headers.origin;
    if (origin) {
      let ok = false;
      try { ok = new URL(origin).host === req.headers.host; } catch (_) { /* inválido */ }
      if (!ok) return json(res, 403, { error: 'Origem não permitida.' });
    }
    if (req.headers['x-requested-with'] !== 'campo') return json(res, 403, { error: 'Requisição inválida.' });
  }

  if (route === 'GET /api/config') return json(res, 200, { mail: MAIL_MODE === 'console' ? 'console' : 'live' });
  if (route === 'GET /api/health') return json(res, 200, { ok: true });
  if (route === 'GET /api/me') { const u = currentUser(req); return json(res, 200, { user: u ? publicUser(u) : null }); }

  if (route === 'POST /api/signup') {
    if (limited('signup:' + ip, 6, 3600000)) return json(res, 429, { error: 'Muitas tentativas. Tente de novo mais tarde.' });
    const b = await readBody(req);
    const name = String(b.name || '').trim().replace(/\s+/g, ' ').slice(0, 80);
    const email = String(b.email || '').trim().toLowerCase();
    if (name.length < 2) return json(res, 400, { error: 'Informe seu nome.' });
    if (!EMAIL_RE.test(email) || email.length > 120) return json(res, 400, { error: 'E-mail inválido.' });
    const pe = pwProblem(b.password); if (pe) return json(res, 400, { error: pe });
    const exists = db.users.find((u) => u.email === email);
    if (exists) {
      const m = mailLayout('Você já tem uma conta', 'Alguém tentou criar uma conta com este e-mail, que já está cadastrado. Se foi você, entre normalmente ou use "Esqueci a senha".', `${BASE_URL}/entrar.html`, 'Ir para o login', 'Se não foi você, nenhuma ação é necessária.');
      await sendMail({ to: email, subject: 'Você já tem uma conta — Campo em Rotação', ...m });
    } else {
      const user = { id: rnd(9), name, email, hash: hashPassword(b.password), verified: false, createdAt: new Date().toISOString() };
      db.users.push(user); save();
      const ok = await sendVerification(user);
      if (!ok) return json(res, 502, { error: 'Conta criada, mas não foi possível enviar o e-mail agora. Entre e peça o reenvio.' }, { 'Set-Cookie': startSession(res, user) });
      return json(res, 201, { ok: true, message: 'Enviamos um link de confirmação para o seu e-mail.' }, { 'Set-Cookie': startSession(res, user) });
    }
    return json(res, 201, { ok: true, message: 'Enviamos um link de confirmação para o seu e-mail.' });
  }

  if (route === 'POST /api/verify') {
    if (limited('verify:' + ip, 30, 3600000)) return json(res, 429, { error: 'Muitas tentativas.' });
    const b = await readBody(req);
    const uid = useToken(b.token, 'verify');
    if (!uid) return json(res, 400, { error: 'Link inválido ou expirado. Entre na sua conta e peça um novo.' });
    const u = db.users.find((x) => x.id === uid);
    if (u) { u.verified = true; save(); }
    return json(res, 200, { ok: true });
  }

  if (route === 'POST /api/resend-verification') {
    const u = currentUser(req);
    if (!u) return json(res, 401, { error: 'Entre na sua conta.' });
    if (u.verified) return json(res, 200, { ok: true, message: 'Seu e-mail já está confirmado.' });
    if (limited('resend:' + u.id, 3, 3600000)) return json(res, 429, { error: 'Você pediu muitos reenvios. Tente em 1 hora.' });
    const ok = await sendVerification(u);
    return ok ? json(res, 200, { ok: true, message: 'Novo link enviado.' }) : json(res, 502, { error: 'Não foi possível enviar o e-mail agora.' });
  }

  if (route === 'POST /api/login') {
    if (limited('login:' + ip, 12, 900000)) return json(res, 429, { error: 'Muitas tentativas. Aguarde 15 minutos.' });
    const b = await readBody(req);
    const email = String(b.email || '').trim().toLowerCase();
    const u = db.users.find((x) => x.email === email);
    let ok = false;
    try { ok = checkPassword(String(b.password || ''), u ? u.hash : DUMMY_HASH) && !!u; } catch (_) { ok = false; }
    if (!ok) return json(res, 401, { error: 'E-mail ou senha incorretos.' });
    return json(res, 200, { user: publicUser(u) }, { 'Set-Cookie': startSession(res, u) });
  }

  if (route === 'POST /api/logout') {
    const sid = parseCookies(req).sid;
    if (sid) { delete db.sessions[sha(sid)]; save(); }
    return json(res, 200, { ok: true }, { 'Set-Cookie': cookieHeader('', 0) });
  }

  if (route === 'POST /api/forgot') {
    if (limited('forgot:' + ip, 5, 3600000)) return json(res, 429, { error: 'Muitas tentativas. Tente mais tarde.' });
    const b = await readBody(req);
    const email = String(b.email || '').trim().toLowerCase();
    const u = db.users.find((x) => x.email === email);
    if (u) {
      const tok = makeToken(u.id, 'reset', RESET_TTL);
      const m = mailLayout('Redefinir senha', 'Recebemos um pedido para redefinir a senha da sua conta. O link vale por 1 hora.', `${BASE_URL}/redefinir.html?token=${tok}`, 'Criar nova senha', 'Se você não pediu isso, ignore esta mensagem. Sua senha continua a mesma.');
      await sendMail({ to: u.email, subject: 'Redefinir senha — Campo em Rotação', ...m });
    }
    return json(res, 200, { ok: true, message: 'Se o e-mail estiver cadastrado, enviamos o link para redefinir a senha.' });
  }

  if (route === 'POST /api/reset') {
    if (limited('reset:' + ip, 15, 3600000)) return json(res, 429, { error: 'Muitas tentativas.' });
    const b = await readBody(req);
    const pe = pwProblem(b.password); if (pe) return json(res, 400, { error: pe });
    const uid = useToken(b.token, 'reset');
    if (!uid) return json(res, 400, { error: 'Link inválido ou expirado.' });
    const u = db.users.find((x) => x.id === uid);
    if (u) {
      u.hash = hashPassword(b.password); u.verified = true; // receber o link no e-mail comprova a posse
      for (const k of Object.keys(db.sessions)) if (db.sessions[k].uid === u.id) delete db.sessions[k];
      save();
    }
    return json(res, 200, { ok: true });
  }

  if (route === 'GET /api/plans') {
    const u = currentUser(req); if (!u) return json(res, 401, { error: 'Entre na sua conta.' });
    return json(res, 200, { plans: db.plans.filter((p) => p.uid === u.id).map((p) => ({ id: p.id, name: p.name, createdAt: p.createdAt, summary: p.summary })).reverse() });
  }
  if (route === 'POST /api/plans') {
    const u = currentUser(req); if (!u) return json(res, 401, { error: 'Entre na sua conta.' });
    if (!u.verified) return json(res, 403, { error: 'Confirme seu e-mail para salvar cenários.', code: 'unverified' });
    const b = await readBody(req);
    const name = String(b.name || '').trim().slice(0, 80) || 'Cenário sem nome';
    const state = b.state;
    if (!state || typeof state !== 'object' || JSON.stringify(state).length > 30000) return json(res, 400, { error: 'Dados do cenário inválidos.' });
    if (db.plans.filter((p) => p.uid === u.id).length >= MAX_PLANS) return json(res, 400, { error: `Limite de ${MAX_PLANS} cenários salvos. Apague algum.` });
    const summary = String(b.summary || '').slice(0, 300);
    const plan = { id: rnd(9), uid: u.id, name, state, summary, createdAt: new Date().toISOString() };
    db.plans.push(plan); save();
    return json(res, 201, { plan: { id: plan.id, name, createdAt: plan.createdAt, summary } });
  }
  let m = url.pathname.match(/^\/api\/plans\/([\w-]+)$/);
  if (m && (req.method === 'GET' || req.method === 'DELETE')) {
    const u = currentUser(req); if (!u) return json(res, 401, { error: 'Entre na sua conta.' });
    const i = db.plans.findIndex((p) => p.id === m[1] && p.uid === u.id);
    if (i < 0) return json(res, 404, { error: 'Cenário não encontrado.' });
    if (req.method === 'GET') return json(res, 200, { plan: db.plans[i] });
    db.plans.splice(i, 1); save();
    return json(res, 200, { ok: true });
  }

  if (route === 'DELETE /api/account') {
    const u = currentUser(req); if (!u) return json(res, 401, { error: 'Entre na sua conta.' });
    if (limited('del:' + u.id, 5, 3600000)) return json(res, 429, { error: 'Muitas tentativas.' });
    const b = await readBody(req);
    let ok = false; try { ok = checkPassword(String(b.password || ''), u.hash); } catch (_) { /* senha errada */ }
    if (!ok) return json(res, 403, { error: 'Senha incorreta.' });
    db.users = db.users.filter((x) => x.id !== u.id);
    db.plans = db.plans.filter((p) => p.uid !== u.id);
    db.tokens = db.tokens.filter((t) => t.uid !== u.id);
    for (const k of Object.keys(db.sessions)) if (db.sessions[k].uid === u.id) delete db.sessions[k];
    save();
    return json(res, 200, { ok: true }, { 'Set-Cookie': cookieHeader('', 0) });
  }

  if (route === 'GET /api/power') {
    if (limited('power:' + ip, 40, 3600000)) return json(res, 429, { error: 'Muitas consultas à NASA. Tente em alguns minutos.' });
    const lat = parseFloat(url.searchParams.get('lat')), lon = parseFloat(url.searchParams.get('lon'));
    if (!(lat >= -90 && lat <= 90) || !(lon >= -180 && lon <= 180)) return json(res, 400, { error: 'Coordenadas inválidas.' });
    try { return json(res, 200, await fetchPower(lat, lon)); }
    catch (e) { return json(res, 502, { error: 'Não foi possível consultar a NASA POWER agora. ' + e.message }); }
  }


  if (route === 'GET /api/history') {
    if (limited('hist:' + ip, 30, 3600000)) return json(res, 429, { error: 'Muitas consultas à NASA. Tente em alguns minutos.' });
    const c = coords(url); if (!c) return json(res, 400, { error: 'Coordenadas inválidas.' });
    try { return json(res, 200, await fetchHistory(c.lat, c.lon)); }
    catch (e) { return json(res, 502, { error: 'Não foi possível obter a série histórica da NASA POWER agora (' + e.message + ').' }); }
  }
  if (route === 'GET /api/weather') {
    if (limited('wx:' + ip, 60, 3600000)) return json(res, 429, { error: 'Muitas consultas de tempo. Tente em alguns minutos.' });
    const c = coords(url); if (!c) return json(res, 400, { error: 'Coordenadas inválidas.' });
    try { return json(res, 200, await fetchWeather(c.lat, c.lon)); }
    catch (e) { return json(res, 502, { error: 'Não foi possível obter a previsão do tempo agora (' + e.message + ').' }); }
  }

  return json(res, 404, { error: 'Rota não encontrada.' });
}

// ---------- arquivos estáticos ----------
function serveStatic(req, res, url) {
  let p = decodeURIComponent(url.pathname);
  if (p.endsWith('/')) p += 'index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, p));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) return send(res, 403, 'Proibido');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(res, 404, 'Página não encontrada', { 'Content-Type': 'text/plain; charset=utf-8' });
    const ext = path.extname(file).toLowerCase();
    const isShell = ext === '.html' || file.endsWith('sw.js');
    send(res, 200, req.method === 'HEAD' ? '' : fs.readFileSync(file), {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': isShell ? 'no-cache' : 'public, max-age=3600'
    });
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Método não permitido');
    return serveStatic(req, res, url);
  } catch (e) {
    if (!res.headersSent) json(res, e.status || 500, { error: e.status ? e.message : 'Erro interno.' });
    if (!e.status) console.error(e);
  }
});
server.listen(PORT, () => {
  console.log(`Campo em Rotação em ${BASE_URL} (porta ${PORT}) · e-mail: ${MAIL_MODE}`);
  if (MAIL_MODE === 'console') console.log('Modo console: os links de confirmação aparecem aqui e em data/outbox.log.');
});
process.on('SIGTERM', () => { flushSync(); process.exit(0); });
process.on('SIGINT', () => { flushSync(); process.exit(0); });
module.exports = { server, flushSync };
