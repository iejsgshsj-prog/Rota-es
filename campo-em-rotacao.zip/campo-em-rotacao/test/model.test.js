'use strict';
const assert = require('node:assert');
const M = require('../public/js/model.js');
const clone = (o) => JSON.parse(JSON.stringify(o));
let fails = 0;
function check(name, fn) { try { fn(); console.log('ok   ' + name); } catch (e) { fails++; console.log('FAIL ' + name + ': ' + e.message); } }

check('ETo plausível nas regiões (0.5–9 mm/dia)', () => {
  for (const [id, r] of Object.entries(M.REGIONS)) {
    const reg = M.prep(r), eto = M.etoMonthly(reg, 0);
    eto.forEach((v, m) => { const d = v / M.MDAYS[m]; assert(d > 0.3 && d < 9.5, `${id} mês ${m}: ${d.toFixed(2)} mm/dia`); });
  }
});
check('aptidão sempre entre 0 e 1', () => {
  const o = clone(M.DEFAULTS);
  for (const r of Object.values(M.REGIONS)) {
    const S = M.suitAll(M.prep(r), o);
    for (const s of Object.values(S)) s.by.forEach((v) => assert(v >= 0 && v <= 1.0001, 'fora de 0-1: ' + v));
  }
});
check('mais calor e menos chuva não melhoram a nota', () => {
  const reg = M.prep(M.REGIONS.petrolina), o = clone(M.DEFAULTS);
  o.dT = 0; o.dP = 0; const a = M.plansFor(M.suitAll(reg, o), o)[0].adapt;
  o.dT = 3; o.dP = -25; const b = M.plansFor(M.suitAll(reg, o), o)[0].adapt;
  assert(b <= a + 1e-9, `${b} > ${a}`);
});
check('irrigação plena não piora a aptidão', () => {
  const reg = M.prep(M.REGIONS.petrolina), o = clone(M.DEFAULTS);
  const a = M.suitAll(reg, o).soja.best; o.irrig = 'full'; const b = M.suitAll(reg, o).soja.best;
  assert(b >= a);
});
check('Sorriso: soja planta entre set e dez; trigo no Iowa não vai bem no inverno', () => {
  const o = clone(M.DEFAULTS); o.dT = 0; o.dP = 0;
  const s = M.suitAll(M.prep(M.REGIONS.sorriso), o).soja;
  assert([8, 9, 10, 11].includes(s.start), 'início ' + M.MONTHS[s.start]);
  const w = M.suitAll(M.prep(M.REGIONS.iowa), o).milho;
  assert([3, 4, 5].includes(w.start), 'milho Iowa ' + M.MONTHS[w.start]);
});
check('planos: 3 conjuntos distintos; respeita culturas permitidas e nº de anos', () => {
  const reg = M.prep(M.REGIONS.sorriso), o = clone(M.DEFAULTS);
  o.allowed = ['soja', 'milho', 'sorgo', 'crotalaria']; o.years = 4;
  const p = M.plansFor(M.suitAll(reg, o), o);
  assert(p.length >= 1 && p[0].ids.length === 4);
  p.forEach((x) => x.ids.forEach((i) => assert(o.allowed.includes(i))));
  o.allowed = M.CROPS.map((c) => c.id); o.years = 3;
  const q = M.plansFor(M.suitAll(reg, o), o);
  assert.strictEqual(q.length, 3);
  assert(q[0].total >= q[1].total && q[1].total >= q[2].total);
});
check('monocultura de gramínea perde de rotação com leguminosa (peso solo alto)', () => {
  const reg = M.prep(M.REGIONS.sorriso), o = clone(M.DEFAULTS); o.wS = 10; o.dT = 0; o.dP = 0;
  const S = M.suitAll(reg, o);
  assert(M.scoreRot(['soja', 'milho', 'crotalaria'], S, o).soil > M.scoreRot(['milho', 'sorgo', 'milho'], S, o).soil);
});
check('teste de estresse devolve grade 5x5 e mínimo coerente', () => {
  const reg = M.prep(M.REGIONS.sorriso), o = clone(M.DEFAULTS);
  const r = M.stress([['soja', 'milho', 'soja'], ['soja', 'sorgo', 'crotalaria']], reg, o);
  assert(r.M[0].length === 5 && r.M[0][0].length === 5);
  assert(Math.min(...r.M[1].flat()) === r.min[1]);
});

// ---------- histórico, tendência, projeção, tempo ----------
const synth = (y0, y1, slopeT, slopeP) => {
  const base = M.prep(M.REGIONS.sorriso), out = [];
  for (let y = y0; y <= y1; y++) out.push({ year: y, t: base.t.map((v) => v + slopeT * (y - y0)), p: base.p.map((v) => v * (1 + slopeP * (y - y0))), tmax: null, tmin: null });
  return out;
};
check('regressão linear recupera inclinação exata e |t| alto', () => {
  const xs = [1, 2, 3, 4, 5, 6, 7, 8], ys = xs.map((x) => 2 + 0.5 * x + (x % 2 ? 0.01 : -0.01));
  const f = M.linfit(xs, ys); assert(Math.abs(f.slope - 0.5) < 0.01 && f.r2 > 0.99 && Math.abs(f.t) > 10);
});
check('regressão sem dados suficientes não quebra', () => { const f = M.linfit([1, 2], [3, 4]); assert(f.slope === 0 && f.n === 2); });
check('período médio fica entre os valores dos anos', () => {
  const base = M.prep(M.REGIONS.sorriso), yrs = synth(1991, 2000, 0.1, 0), r = M.periodReg(yrs, 1991, 2000, base);
  assert(r.count === 10 && Math.abs(r.t[0] - (base.t[0] + 0.45)) < 1e-9 && M.periodReg(yrs, 2010, 2020, base) === null);
});
check('período mais quente e seco nunca tem nota maior (cultura sensível)', () => {
  const base = M.prep(M.REGIONS.passo), o = clone(M.DEFAULTS), yrs = synth(1991, 2020, 0.06, -0.01);
  const a = M.periodReg(yrs, 1991, 2000, base), b = M.periodReg(yrs, 2011, 2020, base);
  const sa = M.suitAll(a, o, 0, 0).milho.best, sb = M.suitAll(b, o, 0, 0).milho.best; assert(sb <= sa + 1e-9, `${sb} > ${sa}`);
});
check('notas por ano ficam entre 0 e 1 e há um valor por ano', () => {
  const base = M.prep(M.REGIONS.sorriso), o = clone(M.DEFAULTS), yrs = M.demoSeries(base, 1991, 2020, 3);
  const sc = M.yearScores(yrs, base, o, [['soja', 'milho', 'soja'], ['soja', 'sorgo', 'crotalaria']]);
  assert(sc.length === 30 && sc.every((s) => s.rots.every((r) => r.total >= 0 && r.total <= 1)));
});
check('tendências e projeção: sinal e ordem dos casos', () => {
  const yrs = synth(1991, 2025, 0.04, -0.004), tr = M.trends(yrs);
  assert(tr.t.slope > 0.035 && tr.t.slope < 0.045 && tr.p.slope < 0);
  const p = M.project(yrs, 2035), c = p.cases;
  assert(p.dT > 0 && p.dP < 0 && c[1].dT >= c[0].dT && c[2].dT <= c[0].dT && c[1].dP <= c[0].dP && c[2].dP >= c[0].dP);
  assert(M.project(yrs, 2045).dT > p.dT);
});
check('aplicar delta muda média e chuva como esperado', () => {
  const reg = M.prep(M.REGIONS.sorriso), r = M.applyDelta(reg, 2, -0.1);
  assert(Math.abs(r.t[3] - (reg.t[3] + 2)) < 1e-9 && Math.abs(r.p[0] - reg.p[0] * 0.9) < 1e-9 && Math.abs(r.tmax[5] - (reg.tmax[5] + 2)) < 1e-9);
});
check('série de demonstração é determinística e completa', () => {
  const base = M.prep(M.REGIONS.sorriso), a = M.demoSeries(base, 1991, 2000, 5), b = M.demoSeries(base, 1991, 2000, 5);
  assert(JSON.stringify(a) === JSON.stringify(b) && a.length === 10 && a.every((y) => y.t.length === 12 && y.p.length === 12 && y.p.every((v) => v >= 0)));
});
check('leitura do tempo: totais, dias secos seguidos e geada', () => {
  const reg = M.prep(M.REGIONS.passo), days = [];
  for (let i = 0; i < 3; i++) days.push({ date: '2026-10-2' + (i + 6), tmax: 24, tmin: 10, rain: 5, et0: 3 });
  const fut = [[0, 12, 1], [0, 11, 0.5], [0, 10, 0.2], [20, 9, 3], [0, -1, 0], [0, 8, 0]];
  fut.forEach((x, i) => days.push({ date: '2026-11-0' + (i + 1), tmax: 25 + (x[0] ? 0 : 11), tmin: x[1], rain: x[0], et0: 4 }));
  const a = M.assessWeather(days, '2026-11-01', reg);
  assert(a.nPast === 3 && a.rainPast === 15 && a.nFut === 6 && a.rainFut === 20 && a.dryRun === 3 && a.frostNights === 1 && a.hotDays >= 3 && a.ratioPast > 0);
});
check('conselho de plantio: janela perto do melhor mês e bloqueio por geada', () => {
  const reg = M.prep(M.REGIONS.passo), o = clone(M.DEFAULTS), S = M.suitAll(reg, o, 0, 0), s = S.soja;
  const ok = M.plantingAdvice(S, ['soja'], s.start, { ratioFut: 1, dryRun: 2, frostNights: 0, hotDays: 0, tmaxFut: 28 })[0];
  assert(ok.window && ok.ok && ok.rel > 0.99);
  const bad = M.plantingAdvice(S, ['soja'], s.start, { ratioFut: 0.3, dryRun: 12, frostNights: 1, hotDays: 0, tmaxFut: 28 })[0];
  assert(!bad.ok && bad.why.length === 3);
});
console.log(fails ? `\n${fails} falha(s)` : '\ntodos os testes do modelo passaram');
process.exit(fails ? 1 : 0);
