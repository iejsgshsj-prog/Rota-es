'use strict';
/* Teste de integração: sobe fornecedores simulados (NASA POWER, previsão do tempo, SMTP) e o servidor real. */
const http = require('node:http');
const net = require('node:net');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert');
const { spawn } = require('node:child_process');

let fails = 0;
const results = [];
async function check(name, fn) { try { await fn(); results.push('ok   ' + name); } catch (e) { fails++; results.push('FAIL ' + name + ': ' + e.message); } }
const listen = (srv) => new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port)));

// ---- fornecedor simulado de dados ----
const END = new Date().getUTCFullYear() - 1;
function powerMonthly() {
  const T2M = {}, T2M_MAX = {}, T2M_MIN = {}, PRECTOTCORR = {};
  for (let y = 1991; y <= END; y++) for (let m = 1; m <= 12; m++) {
    const k = y + String(m).padStart(2, '0'), base = 24 + 0.03 * (y - 1991);
    T2M[k] = base; T2M_MAX[k] = base + 5; T2M_MIN[k] = base - 5; PRECTOTCORR[k] = m >= 5 && m <= 9 ? 0.4 : 6;
  }
  T2M['199503'] = -999; // ano incompleto deve ser descartado
  return { properties: { parameter: { T2M, T2M_MAX, T2M_MIN, PRECTOTCORR } } };
}
function powerClim() {
  const K = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'], o = (v) => Object.fromEntries(K.map((k) => [k, v]));
  return { properties: { parameter: { T2M: o(25), T2M_MAX: o(30), T2M_MIN: o(20), PRECTOTCORR: o(5), ALLSKY_SFC_SW_DWN: o(5), RH2M: o(70) } } };
}
function meteo() {
  const time = [], base = Date.now() - 30 * 86400000;
  for (let i = 0; i < 46; i++) time.push(new Date(base + i * 86400000).toISOString().slice(0, 10));
  return { utc_offset_seconds: 0, daily: { time, temperature_2m_max: time.map(() => 31.24), temperature_2m_min: time.map(() => 19.06), precipitation_sum: time.map((_, i) => (i % 3 ? 0 : 4.5)), et0_fao_evapotranspiration: time.map(() => 4.2) } };
}
const upstream = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  const send = (o) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  if (u.pathname === '/api/temporal/monthly/point') return send(powerMonthly());
  if (u.pathname === '/api/temporal/climatology/point') return send(powerClim());
  if (u.pathname === '/v1/forecast') return send(meteo());
  res.writeHead(404); res.end();
});

// ---- SMTP simulado (sem TLS, só para o teste) ----
const mails = [];
const smtp = net.createServer((sock) => {
  let data = '', inData = false;
  sock.write('220 fake\r\n');
  sock.on('data', (d) => {
    data += d.toString('utf8');
    let i;
    while ((i = data.indexOf('\r\n')) >= 0 || (inData && data.includes('\r\n.\r\n'))) {
      if (inData) {
        const end = data.indexOf('\r\n.\r\n'); if (end < 0) return;
        mails.push(data.slice(0, end)); data = data.slice(end + 5); inData = false; sock.write('250 ok\r\n'); continue;
      }
      const line = data.slice(0, i); data = data.slice(i + 2);
      if (/^EHLO/.test(line)) sock.write('250 fake\r\n');
      else if (/^(MAIL|RCPT)/.test(line)) sock.write('250 ok\r\n');
      else if (/^DATA/.test(line)) { inData = true; sock.write('354 go\r\n'); }
      else if (/^QUIT/.test(line)) { sock.write('221 bye\r\n'); sock.end(); }
    }
  });
});

async function startServer(env) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'campo-'));
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: Object.assign({}, process.env, env, { DATA_DIR: dir }), stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  child.stdout.on('data', (d) => { out += d; }); child.stderr.on('data', (d) => { out += d; });
  const port = env.PORT;
  for (let i = 0; i < 60; i++) {
    try { const r = await fetch(`http://127.0.0.1:${port}/api/health`); if (r.ok) return { child, dir, base: `http://127.0.0.1:${port}`, log: () => out }; } catch (_) { /* aguardando */ }
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error('servidor não subiu: ' + out);
}
function client(base) {
  let cookie = '';
  return async function call(method, url, body, extra) {
    const h = Object.assign({ 'Content-Type': 'application/json', 'X-Requested-With': 'campo' }, extra || {});
    if (cookie) h.Cookie = cookie;
    const r = await fetch(base + url, { method, headers: h, body: body ? JSON.stringify(body) : undefined });
    const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0].replace(/^sid=$/, '');
    let j = {}; try { j = await r.json(); } catch (_) { /* sem corpo */ }
    return { status: r.status, body: j, headers: r.headers };
  };
}
const tokenFrom = (text, page) => { const m = text.match(new RegExp(page + '\\?token=([\\w-]+)', 'g')); return m ? m[m.length - 1].split('=')[1] : null; };

(async () => {
  const upPort = await listen(upstream), smtpPort = await listen(smtp);
  const P = 38000 + Math.floor(Math.random() * 1000);
  const S = await startServer({ PORT: String(P), BASE_URL: `http://127.0.0.1:${P}`, MAIL_MODE: 'console', POWER_BASE: `http://127.0.0.1:${upPort}`, METEO_BASE: `http://127.0.0.1:${upPort}` });
  const call = client(S.base);
  const outbox = () => { try { return fs.readFileSync(path.join(S.dir, 'outbox.log'), 'utf8'); } catch (_) { return ''; } };

  await check('páginas estáticas e cabeçalhos de segurança', async () => {
    const r = await fetch(S.base + '/'); assert.strictEqual(r.status, 200);
    assert(/script-src 'self'/.test(r.headers.get('content-security-policy')) && r.headers.get('x-frame-options') === 'DENY');
    assert.strictEqual((await fetch(S.base + '/../server.js')).status === 200 && false, false);
    assert.notStrictEqual((await fetch(S.base + '/%2e%2e/server.js')).status, 200);
  });
  await check('rotas que alteram dados exigem cabeçalho de proteção', async () => {
    const r = await fetch(S.base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    assert.strictEqual(r.status, 403);
  });
  await check('cadastro valida nome, e-mail e senha', async () => {
    assert.strictEqual((await call('POST', '/api/signup', { name: 'A', email: 'x@y.com', password: 'abc12345' })).status, 400);
    assert.strictEqual((await call('POST', '/api/signup', { name: 'Ana', email: 'invalido', password: 'abc12345' })).status, 400);
    assert.strictEqual((await call('POST', '/api/signup', { name: 'Ana', email: 'ana@exemplo.com', password: 'curta1' })).status, 400);
  });

  const c1 = client(S.base);
  await check('cadastro envia e-mail de confirmação e conta começa não verificada', async () => {
    const r = await c1('POST', '/api/signup', { name: 'Ana Souza', email: 'Ana@Exemplo.com', password: 'senha1234' });
    assert.strictEqual(r.status, 201);
    const me = await c1('GET', '/api/me'); assert(me.body.user && me.body.user.verified === false && me.body.user.email === 'ana@exemplo.com');
    assert(tokenFrom(outbox(), 'verificar.html'), 'link de confirmação não saiu no e-mail');
  });
  await check('não é possível salvar cenário antes de confirmar o e-mail', async () => {
    const r = await c1('POST', '/api/plans', { name: 'x', state: { a: 1 } });
    assert.strictEqual(r.status, 403); assert.strictEqual(r.body.code, 'unverified');
  });
  await check('link de confirmação funciona uma vez só', async () => {
    const tok = tokenFrom(outbox(), 'verificar.html');
    assert.strictEqual((await c1('POST', '/api/verify', { token: 'errado' })).status, 400);
    assert.strictEqual((await c1('POST', '/api/verify', { token: tok })).status, 200);
    assert.strictEqual((await c1('POST', '/api/verify', { token: tok })).status, 400);
    assert.strictEqual((await c1('GET', '/api/me')).body.user.verified, true);
  });
  await check('cadastro repetido não revela se o e-mail existe', async () => {
    const a = await call('POST', '/api/signup', { name: 'Outra', email: 'ana@exemplo.com', password: 'outra12345' });
    assert.strictEqual(a.status, 201); assert(!a.headers.get('set-cookie'));
    assert(/Você já tem uma conta/.test(outbox()));
  });
  await check('login: senha errada, e-mail inexistente e sucesso', async () => {
    const c = client(S.base);
    assert.strictEqual((await c('POST', '/api/login', { email: 'ana@exemplo.com', password: 'errada123' })).status, 401);
    assert.strictEqual((await c('POST', '/api/login', { email: 'ninguem@exemplo.com', password: 'senha1234' })).status, 401);
    assert.strictEqual((await c('POST', '/api/login', { email: 'ana@exemplo.com', password: 'senha1234' })).status, 200);
    assert.strictEqual((await c('GET', '/api/me')).body.user.name, 'Ana Souza');
  });
  await check('cenários: salvar, listar, abrir, isolamento entre contas e apagar', async () => {
    const save = await c1('POST', '/api/plans', { name: 'Teste', state: { dT: 2 }, summary: 'resumo' });
    assert.strictEqual(save.status, 201);
    const list = await c1('GET', '/api/plans'); assert.strictEqual(list.body.plans.length, 1);
    const id = list.body.plans[0].id;
    assert.strictEqual((await c1('GET', '/api/plans/' + id)).body.plan.state.dT, 2);
    const c2 = client(S.base);
    await c2('POST', '/api/signup', { name: 'Beto', email: 'beto@exemplo.com', password: 'senha5678' });
    assert.strictEqual((await c2('GET', '/api/plans/' + id)).status, 404);
    assert.strictEqual((await c1('DELETE', '/api/plans/' + id)).status, 200);
    assert.strictEqual((await c1('GET', '/api/plans')).body.plans.length, 0);
  });
  await check('redefinir senha: link vale uma vez e encerra sessões antigas', async () => {
    const c = client(S.base);
    await c('POST', '/api/login', { email: 'ana@exemplo.com', password: 'senha1234' });
    assert.strictEqual((await call('POST', '/api/forgot', { email: 'naoexiste@exemplo.com' })).status, 200);
    assert.strictEqual((await call('POST', '/api/forgot', { email: 'ana@exemplo.com' })).status, 200);
    const tok = tokenFrom(outbox(), 'redefinir.html'); assert(tok);
    assert.strictEqual((await call('POST', '/api/reset', { token: tok, password: 'curta' })).status, 400);
    assert.strictEqual((await call('POST', '/api/reset', { token: tok, password: 'novasenha99' })).status, 200);
    assert.strictEqual((await call('POST', '/api/reset', { token: tok, password: 'novasenha99' })).status, 400);
    assert.strictEqual((await c('GET', '/api/me')).body.user, null);
    assert.strictEqual((await client(S.base)('POST', '/api/login', { email: 'ana@exemplo.com', password: 'novasenha99' })).status, 200);
  });
  await check('senha nunca fica gravada em texto puro', async () => {
    S.child.kill('SIGTERM'); await new Promise((r) => setTimeout(r, 300));
    const raw = fs.readFileSync(path.join(S.dir, 'db.json'), 'utf8');
    assert(!raw.includes('senha1234') && !raw.includes('novasenha99') && raw.includes('scrypt') === false && /"hash":"[0-9a-f]{32}:[0-9a-f]{128}"/.test(raw));
  });

  // ---- segundo servidor: SMTP real simulado + rotas de dados ----
  const P2 = P + 1;
  const S2 = await startServer({ PORT: String(P2), BASE_URL: `http://127.0.0.1:${P2}`, MAIL_MODE: 'smtp', SMTP_HOST: '127.0.0.1', SMTP_PORT: String(smtpPort), SMTP_PLAIN_TEST: '1', MAIL_FROM: 'Campo <nao-responda@exemplo.com>', POWER_BASE: `http://127.0.0.1:${upPort}`, METEO_BASE: `http://127.0.0.1:${upPort}` });
  const d = client(S2.base);
  await check('senha só com letras é recusada e o cadastro seguinte ainda funciona', async () => {
    assert.strictEqual((await client(S2.base)('POST', '/api/signup', { name: 'Ana', email: 'ana2@exemplo.com', password: 'somenteletras' })).status, 400);
  });
  await check('modo SMTP entrega o e-mail de confirmação com link e texto em UTF-8', async () => {
    const r = await d('POST', '/api/signup', { name: 'Carla', email: 'carla@exemplo.com', password: 'senha4321' });
    assert.strictEqual(r.status, 201);
    for (let i = 0; i < 30 && !mails.length; i++) await new Promise((x) => setTimeout(x, 50));
    assert.strictEqual(mails.length, 1);
    assert(/To: carla@exemplo.com/.test(mails[0]) && /From: Campo/.test(mails[0]));
    const parts = mails[0].split('base64\r\n').slice(1).map((p) => Buffer.from(p.split('\r\n--')[0].replace(/\s/g, ''), 'base64').toString('utf8'));
    assert(parts.some((t) => /verificar\.html\?token=[\w-]{20,}/.test(t)) && parts.some((t) => /Confirme seu e-mail/.test(t)));
  });
  await check('histórico NASA POWER: anos completos, descarta ano incompleto, converte mm/dia em mm/mês', async () => {
    const r = await d('GET', '/api/history?lat=-12.5&lon=-55.7'); assert.strictEqual(r.status, 200);
    const ys = r.body.years, y1991 = ys.find((y) => y.year === 1991);
    assert.strictEqual(ys.length, END - 1991 + 1 - 1);
    assert(!ys.some((y) => y.year === 1995));
    assert.strictEqual(y1991.t.length, 12); assert.strictEqual(y1991.p[0], 186); assert.strictEqual(y1991.p[5], Math.round(0.4 * 30));
    assert(y1991.tmax && Math.abs(y1991.tmax[0] - 29) < 0.01);
    assert(/NASA POWER/.test(r.body.source));
  });
  await check('histórico e tempo rejeitam coordenadas inválidas', async () => {
    assert.strictEqual((await d('GET', '/api/history?lat=abc&lon=1')).status, 400);
    assert.strictEqual((await d('GET', '/api/weather?lat=95&lon=1')).status, 400);
  });
  await check('tempo: 46 dias, hoje identificado, valores numéricos', async () => {
    const r = await d('GET', '/api/weather?lat=-12.5&lon=-55.7'); assert.strictEqual(r.status, 200);
    assert.strictEqual(r.body.days.length, 46); assert(/^\d{4}-\d\d-\d\d$/.test(r.body.today));
    assert(r.body.days.every((x) => typeof x.rain === 'number' && typeof x.tmax === 'number'));
    assert(r.body.days.filter((x) => x.date < r.body.today).length === 30, 'esperava 30 dias passados');
    assert(/Open-Meteo/.test(r.body.source));
  });
  await check('climatologia NASA POWER continua funcionando', async () => {
    const r = await d('GET', '/api/power?lat=-12.5&lon=-55.7'); assert.strictEqual(r.status, 200);
    assert.strictEqual(r.body.t.length, 12); assert.strictEqual(r.body.p[0], 155);
  });
  S2.child.kill('SIGTERM');

  // ---- fornecedor fora do ar ----
  const P3 = P + 2;
  const S3 = await startServer({ PORT: String(P3), BASE_URL: `http://127.0.0.1:${P3}`, POWER_BASE: 'http://127.0.0.1:1', METEO_BASE: 'http://127.0.0.1:1' });
  await check('fornecedor fora do ar devolve erro claro (502), sem derrubar o servidor', async () => {
    const e = client(S3.base);
    const a = await e('GET', '/api/history?lat=1&lon=1'), b = await e('GET', '/api/weather?lat=1&lon=1');
    assert.strictEqual(a.status, 502); assert.strictEqual(b.status, 502); assert(/Não foi possível/.test(a.body.error));
    assert.strictEqual((await e('GET', '/api/health')).status, 200);
  });
  S3.child.kill('SIGTERM');

  console.log(results.join('\n'));
  console.log(fails ? `\n${fails} falha(s)` : '\ntodos os testes do servidor passaram');
  upstream.close(); smtp.close();
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(results.join('\n')); console.error('erro no teste:', e); process.exit(1); });
